#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${PYTHON:-python3}"
MODULE_NAME="agent_runtime"
VERSION="$(cat "$ROOT_DIR/VERSION")"
BUILD_PYTHON_VERSION="$(cat "$ROOT_DIR/PYTHON_VERSION")"
CURRENT_PYTHON_VERSION="$($PYTHON_BIN - <<'PY'
import sys
print(".".join(map(str, sys.version_info[:3])))
PY
)"

if [[ "${BUILD_PYTHON_VERSION%.*}" != "${CURRENT_PYTHON_VERSION%.*}" ]]; then
  echo "Python minor version mismatch." >&2
  echo "Package was compiled with Python $BUILD_PYTHON_VERSION, current Python is $CURRENT_PYTHON_VERSION." >&2
  exit 1
fi

if [[ -d "$ROOT_DIR/wheelhouse" && -s "$ROOT_DIR/requirements.txt" ]]; then
  "$PYTHON_BIN" -m pip install \
    --no-index \
    --find-links "$ROOT_DIR/wheelhouse" \
    --requirement "$ROOT_DIR/requirements.txt"
fi

SITE_PACKAGES="$($PYTHON_BIN - <<'PY'
import sysconfig
print(sysconfig.get_paths()["purelib"])
PY
)"
SCRIPTS_DIR="$($PYTHON_BIN - <<'PY'
import sysconfig
print(sysconfig.get_paths()["scripts"])
PY
)"
PYTHON_EXE="$($PYTHON_BIN - <<'PY'
import sys
print(sys.executable)
PY
)"

mkdir -p "$SITE_PACKAGES" "$SCRIPTS_DIR"
rm -rf "$SITE_PACKAGES/$MODULE_NAME" "$SITE_PACKAGES/${MODULE_NAME}-${VERSION}.dist-info"
cp -R "$ROOT_DIR/python/$MODULE_NAME" "$SITE_PACKAGES/$MODULE_NAME"
cp -R "$ROOT_DIR/dist-info/${MODULE_NAME}-${VERSION}.dist-info" \
  "$SITE_PACKAGES/${MODULE_NAME}-${VERSION}.dist-info"

cat > "$SCRIPTS_DIR/agent-runtime" <<SCRIPT
#!$PYTHON_EXE
import sys
from agent_runtime.cli import main
raise SystemExit(main())
SCRIPT
chmod +x "$SCRIPTS_DIR/agent-runtime"

"$PYTHON_BIN" - <<'PY'
from agent_runtime import RuntimeService, RuntimeSettings
print("agent_runtime import ok")
PY

echo "Installed agent-runtime $VERSION into $SITE_PACKAGES"
echo "CLI installed at $SCRIPTS_DIR/agent-runtime"
