from agent_runtime import RuntimeService, RuntimeSettings

print("agent_runtime import ok")
print(RuntimeService.__name__, RuntimeSettings.__name__)
