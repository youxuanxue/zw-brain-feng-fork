AgentRuntime offline binary package
===================================

Package: agent-runtime
Version: 1.1.2.2
Compiled with: Python 3.12.12
Payload: python/agent_runtime contains .pyc bytecode files, not .py source files.

Install into the current Python environment:

  ./install.sh

Use another Python executable:

  PYTHON=/path/to/python ./install.sh

Verify after install:

  python -c "from agent_runtime import RuntimeService, RuntimeSettings; print('ok')"
  agent-runtime --help

Dependency behavior:

- If wheelhouse/ exists, install.sh installs dependencies from local wheels only.
- This package itself is installed by copying compiled files into site-packages;
  it does not install agent-runtime from PyPI or from a private package index.

Important:

- .pyc bytecode is compatible only with the same Python major/minor version.
- .pyc bytecode hides source files but is not strong code protection.
- Rebuild this package separately for each supported Python minor version.
