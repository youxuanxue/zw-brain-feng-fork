(function () {
  "use strict";

  const STORAGE_KEY = "agent-runtime.chat-v1.sessions";
  const ACTIVE_KEY = "agent-runtime.chat-v1.active-session";
  const MSG_PREFIX = "agent-runtime.chat-v1.messages:";
  const TRACE_PREFIX = "agent-runtime.chat-v1.trace:";

  const el = {
    agentSelect: byId("v1-agent-select"),
    agentTitle: byId("v1-agent-title"),
    banner: byId("v1-session-banner"),
    cancel: byId("v1-cancel"),
    contextAgent: byId("v1-context-agent"),
    contextMode: byId("v1-context-mode"),
    emptyState: byId("v1-empty-state"),
    error: byId("v1-error"),
    messages: byId("v1-messages"),
    mode: byId("v1-task-mode"),
    newSession: byId("v1-new-session"),
    refreshSessions: byId("v1-refresh-sessions"),
    resume: byId("v1-resume"),
    send: byId("v1-send"),
    sessionFilter: byId("v1-session-filter"),
    sessionList: byId("v1-session-list"),
    status: byId("v1-status"),
    userInput: byId("v1-user-input"),
    waitingInput: byId("v1-waiting-input"),
    waitingPanel: byId("v1-waiting-panel"),
    waitingTitle: byId("v1-waiting-title"),
    workspaceList: byId("v1-workspace-list"),
  };

  const state = {
    activeSessionId: localStorage.getItem(ACTIVE_KEY) || "",
    activeTaskId: "",
    agents: [],
    busy: false,
    eventSource: null,
    filter: "",
    sessions: loadSessions(),
    streamingAssistantMessageId: "",
    streamingSessionId: "",
    waitingTaskId: "",
  };

  function byId(id) {
    return document.getElementById(id);
  }

  function safeParse(json, fallback) {
    try {
      const value = JSON.parse(json);
      return value == null ? fallback : value;
    } catch {
      return fallback;
    }
  }

  async function fetchJson(url, options) {
    const response = await fetch(url, options);
    const text = await response.text();
    let payload = null;
    if (text) {
      try {
        payload = JSON.parse(text);
      } catch {
        payload = { raw: text };
      }
    }
    if (!response.ok) {
      const detail = payload && (payload.detail || payload.error || payload.message);
      throw new Error(typeof detail === "string" ? detail : `${response.status} ${response.statusText}`);
    }
    return payload;
  }

  function loadSessions() {
    const parsed = safeParse(localStorage.getItem(STORAGE_KEY) || "[]", []);
    return Array.isArray(parsed) ? parsed : [];
  }

  function saveSessions() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state.sessions.slice(0, 80)));
    if (state.activeSessionId) localStorage.setItem(ACTIVE_KEY, state.activeSessionId);
  }

  function setActiveSessionId(sessionId) {
    state.activeSessionId = sessionId || "";
    if (state.activeSessionId) localStorage.setItem(ACTIVE_KEY, state.activeSessionId);
    else localStorage.removeItem(ACTIVE_KEY);
  }

  function messageKey(sessionId) {
    return MSG_PREFIX + sessionId;
  }

  function loadMessages(sessionId) {
    if (!sessionId) return [];
    const parsed = safeParse(localStorage.getItem(messageKey(sessionId)) || "[]", []);
    return Array.isArray(parsed) ? parsed : [];
  }

  function saveMessages(sessionId, messages) {
    if (!sessionId) return;
    localStorage.setItem(messageKey(sessionId), JSON.stringify(messages.slice(-200)));
  }

  function traceKey(messageId) {
    return TRACE_PREFIX + messageId;
  }

  function saveStoredTrace(sessionId, messageId, events) {
    if (!sessionId || !messageId) return;
    try {
      localStorage.setItem(traceKey(messageId), JSON.stringify(events.slice(-200)));
    } catch {
      /* 存储满时静默忽略 */
    }
  }

  function loadStoredTrace(sessionId, messageId) {
    if (!sessionId || !messageId) return [];
    try {
      const raw = localStorage.getItem(traceKey(messageId));
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }

  function newMessageId(role) {
    return `${role}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }

  function appendStoredMessage(sessionId, message) {
    if (!sessionId) return null;
    const next = {
      id: message.id || newMessageId(message.role || "msg"),
      agentId: message.agentId || sessionAgentId(activeSession()),
      role: message.role,
      status: message.status || "done",
      text: message.text || "",
      ts: message.ts || Date.now(),
    };
    const messages = loadMessages(sessionId);
    messages.push(next);
    saveMessages(sessionId, messages);
    return next;
  }

  function upsertStoredMessage(sessionId, messageId, patch) {
    if (!sessionId || !messageId) return;
    const messages = loadMessages(sessionId);
    const idx = messages.findIndex((item) => item.id === messageId);
    if (idx < 0) {
      messages.push({ id: messageId, agentId: sessionAgentId(activeSession()), role: "assistant", text: "", ts: Date.now(), ...patch });
    } else {
      messages[idx] = { ...messages[idx], ...patch, updatedAt: Date.now() };
    }
    saveMessages(sessionId, messages);
  }

  function selectedAgentId() {
    return el.agentSelect.value || (state.agents[0] && state.agents[0].agent_id) || "";
  }

  function agentName(agentId) {
    const agent = state.agents.find((item) => item.agent_id === agentId);
    return (agent && (agent.name || agent.display_name || agent.agent_id)) || agentId || "Agent";
  }

  function metadataAgentId(metadata) {
    if (!metadata || typeof metadata !== "object") return "";
    return metadata.agent_id || metadata.agentId || "";
  }

  function sessionAgentId(session) {
    if (!session) return "";
    return session.agentId || metadataAgentId(session.metadata) || "";
  }

  function sessionTitle(session) {
    if (!session) return "AgentRuntime";
    if (session.title) return session.title;
    const aid = sessionAgentId(session);
    return aid ? agentName(aid) : "未知会话";
  }

  function formatTime(value) {
    const date = value ? new Date(value) : new Date();
    return date.toLocaleString("zh-CN", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  }

  function defaultSessionTitle(agentId) {
    return `${agentName(agentId)} · ${formatTime(Date.now())}`;
  }

  function upsertSession(entry) {
    const now = Date.now();
    const existing =
      state.sessions.find((item) => item.sessionId === (entry.sessionId || entry.session_id)) || {};
    const metadata = entry.metadata || existing.metadata || {};
    const entryAgentId = entry.agentId || entry.agent_id || metadataAgentId(metadata);
    const normalized = {
      agentId: entryAgentId || existing.agentId || "",
      createdAt: entry.createdAt || entry.created_at || existing.createdAt || now,
      lastTaskId: entry.lastTaskId || entry.last_task_id || existing.lastTaskId || "",
      mode: entry.mode || existing.mode || "one_shot",
      metadata,
      sessionId: entry.sessionId || entry.session_id,
      status: entry.status || existing.status || "idle",
      title:
        entry.title ||
        existing.title ||
        defaultSessionTitle(entryAgentId || existing.agentId || selectedAgentId()),
      updatedAt: entry.updatedAt || entry.updated_at || existing.updatedAt || now,
      workspaceId: entry.workspaceId || entry.workspace_id || existing.workspaceId || "",
    };
    if (!normalized.sessionId) return null;
    const idx = state.sessions.findIndex((item) => item.sessionId === normalized.sessionId);
    if (idx >= 0) state.sessions[idx] = { ...state.sessions[idx], ...normalized };
    else state.sessions.unshift(normalized);
    state.sessions.sort((a, b) => (new Date(b.updatedAt).getTime() || 0) - (new Date(a.updatedAt).getTime() || 0));
    saveSessions();
    return normalized;
  }

  function activeSession() {
    return state.sessions.find((item) => item.sessionId === state.activeSessionId) || null;
  }

  function showError(message) {
    el.error.textContent = message || "";
    el.error.hidden = !message;
  }

  function setStatus(message) {
    if (el.status) el.status.textContent = message || "idle";
  }

  function setBusy(value) {
    state.busy = value;
    el.send.disabled = value;
    el.cancel.disabled = !value || !state.activeTaskId;
    el.userInput.disabled = value;
    el.agentSelect.disabled = value;
    el.mode.disabled = value;
    el.newSession.disabled = value;
    el.refreshSessions.disabled = value;
  }

  function closeStream() {
    if (state.eventSource) {
      state.eventSource.close();
      state.eventSource = null;
    }
    if (state.streamingSessionId && state.streamingAssistantMessageId) {
      upsertStoredMessage(state.streamingSessionId, state.streamingAssistantMessageId, { status: "已中断" });
    }
    state.activeTaskId = "";
    state.streamingAssistantMessageId = "";
    state.streamingSessionId = "";
    setBusy(false);
  }

  function applySessionControls(session) {
    if (!session) return;
    const agentId = sessionAgentId(session);
    if (agentId && Array.from(el.agentSelect.options).some((option) => option.value === agentId)) {
      el.agentSelect.value = agentId;
    }
    el.mode.value = session.mode === "durable" ? "durable" : "one_shot";
  }

  function updateActiveSession(patch) {
    const session = activeSession();
    if (!session) return;
    upsertSession({ ...session, ...patch, updatedAt: Date.now() });
    renderSessions();
    renderWorkspace();
  }

  function syncLabels() {
    const sid = state.activeSessionId;
    const session = activeSession();
    const agentId = sessionAgentId(session);
    el.agentTitle.textContent = sessionTitle(session);
    if (el.contextAgent) el.contextAgent.textContent = agentId ? agentName(agentId) : "未选择";
    if (el.contextMode) el.contextMode.textContent = (session && session.mode) || el.mode.value;
    if (!sid) {
      el.banner.textContent = "选择左侧会话或新建会话开始。";
    } else if (session && session.lastTaskId) {
      el.banner.textContent = `最近任务 ${shortId(session.lastTaskId)} · ${session.status || "idle"}`;
    } else {
      el.banner.textContent = "本会话暂无任务记录。";
    }
    renderWorkspace();
  }

  function renderSessions() {
    const query = state.filter.trim().toLowerCase();
    el.sessionList.innerHTML = "";
    for (const item of state.sessions) {
      const haystack = `${item.title} ${item.agentId} ${item.sessionId} ${item.lastTaskId}`.toLowerCase();
      if (query && !haystack.includes(query)) continue;
      const card = document.createElement("button");
      card.type = "button";
      card.className = "session-card" + (item.sessionId === state.activeSessionId ? " active" : "");
      card.setAttribute("role", "option");
      card.setAttribute("aria-selected", item.sessionId === state.activeSessionId ? "true" : "false");
      const title = document.createElement("p");
      title.className = "session-name";
      title.textContent = item.title;
      const meta = document.createElement("p");
      meta.className = "session-meta";
      meta.textContent = `${item.status || "idle"} · ${item.mode || "one_shot"} · ${shortId(item.lastTaskId || item.sessionId)}`;
      card.append(title, meta);
      card.addEventListener("click", () => selectSession(item.sessionId));
      el.sessionList.appendChild(card);
    }
  }

  function shortId(value) {
    return value ? `${String(value).slice(0, 8)}...` : "no task";
  }

  function selectSession(sessionId) {
    if (state.activeSessionId === sessionId) {
      syncLabels();
      return;
    }
    closeStream();
    setActiveSessionId(sessionId);
    state.waitingTaskId = "";
    el.waitingInput.value = "";
    el.waitingPanel.classList.add("hidden");
    applySessionControls(activeSession());
    renderStoredMessages(sessionId);
    renderSessions();
    syncLabels();
    setStatus(activeSession() ? activeSession().status : "idle");
    showError("");
    void hydrateSessionFromServer(sessionId);
  }

  async function createSession() {
    const agentId = selectedAgentId();
    if (!agentId) throw new Error("请先选择 Agent。");
    const title = defaultSessionTitle(agentId);
    const payload = await fetchJson("/sessions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title,
        trust_level: "verified",
        metadata: { source: "chat-v1", agent_id: agentId },
      }),
    });
    const session = upsertSession({
      agentId,
      createdAt: payload.created_at || Date.now(),
      mode: el.mode.value,
      metadata: payload.metadata || {},
      sessionId: payload.session_id,
      status: "created",
      title: payload.title || title,
      updatedAt: payload.updated_at || Date.now(),
      workspaceId: payload.workspace_id || "",
    });
    setActiveSessionId(session.sessionId);
    renderStoredMessages(session.sessionId);
    renderSessions();
    syncLabels();
    return session;
  }

  async function ensureSession() {
    return activeSession() || createSession();
  }

  async function loadAgents() {
    state.agents = await fetchJson("/agents");
    el.agentSelect.innerHTML = "";
    for (const agent of state.agents) {
      const option = document.createElement("option");
      option.value = agent.agent_id;
      option.textContent = agent.name || agent.display_name || agent.agent_id;
      el.agentSelect.appendChild(option);
    }
    syncLabels();
  }

  async function refreshRemoteSessions() {
    const remote = await fetchJson("/sessions");
    for (const session of remote) {
      upsertSession({
        createdAt: session.created_at,
        metadata: session.metadata || {},
        sessionId: session.session_id,
        status: session.status || "remote",
        title: session.title,
        updatedAt: session.updated_at,
        workspaceId: session.workspace_id || "",
      });
    }
    if (state.activeSessionId && !state.sessions.some((session) => session.sessionId === state.activeSessionId)) {
      setActiveSessionId(state.sessions[0] ? state.sessions[0].sessionId : "");
    }
    renderSessions();
    applySessionControls(activeSession());
    renderStoredMessages(state.activeSessionId);
    syncLabels();
    if (state.activeSessionId) void hydrateSessionFromServer(state.activeSessionId);
  }

  async function hydrateSessionFromServer(sessionId) {
    if (!sessionId) return;
    let payload;
    try {
      payload = await fetchJson(`/sessions/${encodeURIComponent(sessionId)}/state`);
    } catch {
      return;
    }
    const remote = (payload && payload.session) || {};
    const tasks = Array.isArray(payload && payload.tasks) ? payload.tasks : [];
    const lastTask = tasks.length ? tasks[tasks.length - 1] : null;
    const inferredAgentId = (lastTask && lastTask.agent_id) || metadataAgentId(remote.metadata);
    const inferredMode = lastTask && lastTask.mode ? lastTask.mode : undefined;
    upsertSession({
      sessionId,
      agentId: inferredAgentId || undefined,
      createdAt: remote.created_at,
      lastTaskId: lastTask ? lastTask.task_id : undefined,
      metadata: remote.metadata || {},
      mode: inferredMode,
      status: remote.status || (lastTask && lastTask.status) || "remote",
      title: remote.title,
      updatedAt: remote.updated_at,
      workspaceId: remote.workspace_id || "",
    });
    const serverMessages = Array.isArray(payload && payload.messages) ? payload.messages : [];
    if (loadMessages(sessionId).length === 0) {
      if (serverMessages.length) {
        synthesizeMessagesFromServer(sessionId, serverMessages);
      } else if (tasks.length) {
        synthesizeMessagesFromTasks(sessionId, tasks);
      }
    }
    if (state.activeSessionId === sessionId) {
      applySessionControls(activeSession());
      renderStoredMessages(sessionId);
      renderSessions();
      syncLabels();
    } else {
      renderSessions();
    }
  }

  function synthesizeMessagesFromServer(sessionId, serverMessages) {
    const messages = [];
    for (const msg of serverMessages) {
      let text;
      if (msg.content_type === "text" || typeof msg.content === "string") {
        text = msg.content || "";
      } else if (msg.content != null) {
        text = JSON.stringify(msg.content, null, 2);
      } else {
        text = "";
      }
      messages.push({
        id: msg.message_id,
        agentId: msg.agent_id || "",
        role: msg.role === "user" ? "user" : "assistant",
        status: "done",
        text: text,
        ts: Date.parse(msg.created_at) || Date.now(),
      });
    }
    saveMessages(sessionId, messages);
  }

  function synthesizeMessagesFromTasks(sessionId, tasks) {
    const messages = [];
    for (const task of tasks) {
      const startedAt = Date.parse(task.started_at || task.created_at || "") || Date.now();
      const finishedAt = Date.parse(task.finished_at || task.completed_at || task.updated_at || "") || startedAt;
      messages.push({
        id: `task-${task.task_id}-user`,
        agentId: task.agent_id || "",
        role: "user",
        status: "done",
        text: task.input_summary || "(无输入摘要)",
        ts: startedAt,
      });
      const finalText = formatFinalOutput(task.final_output);
      const errorText = task.error ? formatTaskError(task.error) : "";
      const body = finalText || errorText;
      if (body) {
        messages.push({
          id: `task-${task.task_id}-assistant`,
          agentId: task.agent_id || "",
          role: "assistant",
          status: task.status || "done",
          text: body,
          ts: finishedAt,
        });
      }
    }
    saveMessages(sessionId, messages);
  }

  function effectiveWorkspaceId(session) {
    if (!session) return "";
    return session.workspaceId || `session-${session.sessionId}`;
  }

  let workspaceRenderToken = 0;

  function renderWorkspace() {
    workspaceRenderToken += 1;
    const token = workspaceRenderToken;
    const session = activeSession();
    el.workspaceList.innerHTML = "";
    if (!session) {
      el.workspaceList.appendChild(workspaceEmpty("选择或创建会话后显示工作区内容。"));
      return;
    }
    const workspaceId = effectiveWorkspaceId(session);
    renderWorkspaceContext(session, workspaceId);
    renderWorkspaceActivity(session.sessionId);
    renderWorkspaceFiles(workspaceId, token).catch((err) => {
      if (token !== workspaceRenderToken) return;
      el.workspaceList.appendChild(
        workspaceEmpty(`无法加载工作区文件：${err.message || err}`)
      );
    });
  }

  function workspaceEmpty(text) {
    const node = document.createElement("div");
    node.className = "workspace-empty";
    node.textContent = text;
    return node;
  }

  function workspaceSectionHeader(label, count) {
    const header = document.createElement("div");
    header.className = "workspace-section-header";
    const title = document.createElement("span");
    title.textContent = label;
    header.appendChild(title);
    if (count != null) {
      const badge = document.createElement("span");
      badge.className = "workspace-section-count";
      badge.textContent = String(count);
      header.appendChild(badge);
    }
    return header;
  }

  function renderWorkspaceContext(session, workspaceId) {
    el.workspaceList.appendChild(workspaceSectionHeader("上下文"));
    const items = [
      ["workspace", "workspace_id", workspaceId || "未绑定"],
      ["task", "last_task_id", session.lastTaskId || "暂无任务"],
    ];
    for (const [icon, label, value] of items) {
      const row = document.createElement("div");
      row.className = "workspace-file";
      const mark = document.createElement("span");
      mark.className = `file-icon ${icon}`;
      const text = document.createElement("div");
      text.className = "workspace-file-text";
      const name = document.createElement("span");
      name.textContent = label;
      const detail = document.createElement("code");
      detail.textContent = value;
      text.append(name, detail);
      row.append(mark, text);
      el.workspaceList.appendChild(row);
    }
  }

  function loadSessionActivity(sessionId) {
    if (!sessionId) return [];
    const messages = loadMessages(sessionId);
    const seen = new Map();
    for (const message of messages) {
      if (message.role !== "assistant") continue;
      const { items } = extractActivity(message.text || "");
      for (const item of items) {
        const ts = message.updatedAt || message.ts || 0;
        const existing = seen.get(item.path);
        if (!existing || (existing.ts || 0) <= ts) {
          seen.set(item.path, { ...item, ts });
        }
      }
    }
    return Array.from(seen.values()).sort((a, b) => (b.ts || 0) - (a.ts || 0));
  }

  function renderWorkspaceActivity(sessionId) {
    const session = activeSession();
    const items = loadSessionActivity(sessionId);
    el.workspaceList.appendChild(
      workspaceSectionHeader("会话内文件操作", items.length)
    );
    if (!items.length) {
      el.workspaceList.appendChild(
        workspaceEmpty("等待 Agent 发起读写后会出现在这里。")
      );
      return;
    }
    const workspaceId = effectiveWorkspaceId(session);
    const agentId = sessionAgentId(session);
    for (const item of items) {
      const row = document.createElement("div");
      row.className = "workspace-file";
      const mark = makeFileIcon(item.path);
      const text = document.createElement("div");
      text.className = "workspace-file-text";
      const name = document.createElement("span");
      name.textContent = item.path;
      const detail = document.createElement("code");
      detail.textContent = ACTIVITY_VERB_LABEL[item.verb] || item.verb;
      text.append(name, detail);
      row.append(mark, text);
      const actions = document.createElement("div");
      actions.className = "workspace-file-actions";
      const downloadBtn = makeDownloadButton(() =>
        downloadActivityItem(item.path, { workspaceId, agentId })
      );
      actions.appendChild(downloadBtn);
      row.appendChild(actions);
      el.workspaceList.appendChild(row);
    }
  }

  async function renderWorkspaceFiles(workspaceId, token) {
    const header = workspaceSectionHeader("工作区文件");
    el.workspaceList.appendChild(header);
    if (!workspaceId) {
      el.workspaceList.appendChild(workspaceEmpty("尚未绑定工作区。"));
      return;
    }
    let payload;
    try {
      payload = await fetchJson(
        `/workspaces/${encodeURIComponent(workspaceId)}/files`
      );
    } catch (err) {
      if (token !== workspaceRenderToken) return;
      el.workspaceList.appendChild(
        workspaceEmpty("等待 Agent 在 workspace 中写入文件后自动出现。")
      );
      return;
    }
    if (token !== workspaceRenderToken) return;
    const entries = (payload && payload.entries) || [];
    if (!entries.length) {
      el.workspaceList.appendChild(
        workspaceEmpty("工作区暂无文件。Agent 写入后会自动出现。")
      );
      return;
    }
    for (const entry of entries) {
      const row = document.createElement("div");
      row.className = "workspace-file";
      row.dataset.path = entry.path;
      row.dataset.workspaceId = workspaceId;
      const mark = entry.is_dir ? makeBadgeIcon("DIR", "dir") : makeFileIcon(entry.path);
      const text = document.createElement("div");
      text.className = "workspace-file-text";
      const name = document.createElement("span");
      name.textContent = entry.path;
      const detail = document.createElement("code");
      detail.textContent = entry.is_dir ? "<dir>" : `${entry.size || 0} B`;
      text.append(name, detail);
      row.append(mark, text);
      const actions = document.createElement("div");
      actions.className = "workspace-file-actions";
      if (!entry.is_dir) {
        const previewBtn = makeIconButton("查看", () =>
          openWorkspaceFile(workspaceId, entry.path)
        );
        const downloadBtn = makeDownloadButton(() =>
          downloadWorkspaceFile(workspaceId, entry.path)
        );
        actions.append(previewBtn, downloadBtn);
      }
      row.appendChild(actions);
      el.workspaceList.appendChild(row);
    }
  }

  const FILE_KIND_BY_EXT = {
    md: "doc", txt: "doc", rst: "doc",
    pdf: "doc",
    pptx: "deck", ppt: "deck", key: "deck",
    docx: "doc", doc: "doc",
    xlsx: "sheet", xls: "sheet", csv: "sheet", tsv: "sheet",
    json: "data", yaml: "data", yml: "data", toml: "data", xml: "data", env: "data",
    js: "code", mjs: "code", cjs: "code", ts: "code", tsx: "code", jsx: "code",
    py: "code", rb: "code", go: "code", rs: "code", java: "code", kt: "code",
    sh: "shell", bash: "shell", zsh: "shell", fish: "shell",
    html: "code", htm: "code", css: "code", scss: "code",
    png: "image", jpg: "image", jpeg: "image", gif: "image", webp: "image", svg: "image",
    mp4: "media", mov: "media", mp3: "media", wav: "media",
    zip: "archive", tar: "archive", gz: "archive",
  };

  function pathExtension(path) {
    const m = String(path || "").match(/\.([A-Za-z0-9]{1,8})$/);
    return m ? m[1].toLowerCase() : "";
  }

  function pathBasename(path) {
    const segments = String(path || "").split("/");
    return segments[segments.length - 1] || String(path || "");
  }

  function makeFileIcon(path) {
    const ext = pathExtension(path);
    const label = ext ? ext.toUpperCase() : "FILE";
    const kind = FILE_KIND_BY_EXT[ext] || "file";
    return makeBadgeIcon(label, kind);
  }

  function makeBadgeIcon(label, kind) {
    const span = document.createElement("span");
    span.className = `file-icon ext kind-${kind}`;
    span.dataset.label = label.length > 4 ? label.slice(0, 4) : label;
    return span;
  }

  function makeIconButton(label, handler) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "workspace-file-action";
    btn.textContent = label;
    btn.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      handler();
    });
    return btn;
  }

  function makeDownloadButton(handler) {
    return makeIconButton("下载", handler);
  }

  function triggerDownload(url, filename) {
    const link = document.createElement("a");
    link.href = url;
    if (filename) link.download = filename;
    link.rel = "noopener";
    document.body.appendChild(link);
    link.click();
    link.remove();
  }

  function downloadWorkspaceFile(workspaceId, path) {
    if (!workspaceId || !path) return;
    const url =
      `/workspaces/${encodeURIComponent(workspaceId)}/files/content` +
      `?path=${encodeURIComponent(path)}&download=true`;
    triggerDownload(url, pathBasename(path));
  }

  function downloadActivityItem(virtualPath, ctx) {
    if (!virtualPath) return;
    const workspaceId = ctx && ctx.workspaceId;
    const agentId = ctx && ctx.agentId;
    if (workspaceId && virtualPath.startsWith("/workspace/")) {
      const inside = virtualPath.replace(/^\/workspace\/+/, "");
      downloadWorkspaceFile(workspaceId, inside);
      return;
    }
    if (agentId) {
      const url =
        `/agents/${encodeURIComponent(agentId)}/files/content` +
        `?virtual_path=${encodeURIComponent(virtualPath)}&download=true`;
      triggerDownload(url, pathBasename(virtualPath));
      return;
    }
    window.alert(
      "无法下载：当前会话没有绑定 Agent，且路径不在 /workspace/ 下。\n" +
        virtualPath
    );
  }

  async function openWorkspaceFile(workspaceId, path) {
    try {
      const payload = await fetchJson(
        `/workspaces/${encodeURIComponent(workspaceId)}/files/content?path=${encodeURIComponent(path)}`
      );
      const encoding = (payload && payload.encoding) || "utf-8";
      const content = (payload && payload.content) || "";
      const body =
        encoding === "base64"
          ? `[binary file]\n${content.slice(0, 256)}...`
          : content;
      window.alert(`${path}\n\n${body.slice(0, 2000)}`);
    } catch (err) {
      window.alert(`读取文件失败: ${err.message || err}`);
    }
  }

  function resetMessages(showEmpty) {
    el.messages.innerHTML = "";
    el.messages.appendChild(el.emptyState);
    el.emptyState.hidden = !showEmpty;
  }

  function renderStoredMessages(sessionId) {
    const messages = loadMessages(sessionId);
    resetMessages(messages.length === 0);
    if (!messages.length) return;
    el.emptyState.hidden = true;
    for (const message of messages) {
      const storedTraceEvents = message.role === "assistant" ? loadStoredTrace(sessionId, message.id) : [];
      const turn = appendTurn(message.role, message.text || "", {
        agentId: message.agentId,
        messageId: message.id,
        restored: true,
        trace: storedTraceEvents.length > 0,
        status: message.status || "done",
      });
      // 恢复trace事件
      if (storedTraceEvents.length && turn.trace) {
        for (const te of storedTraceEvents) {
          turn.trace.add(te.name, te.payload || {});
        }
      }
    }
    scrollMessages();
  }

  function renderMarkdown(target, markdown) {
    const source = markdown || "";
    if (window.marked && window.DOMPurify) {
      target.innerHTML = window.DOMPurify.sanitize(window.marked.parse(source));
      target.querySelectorAll("pre code").forEach((block) => {
        if (window.hljs) window.hljs.highlightElement(block);
      });
      return;
    }
    target.textContent = source;
  }

  const ACTIVITY_VERBS = ["Updated", "Created", "Read", "Wrote", "Modified", "Deleted", "Listed"];
  const ACTIVITY_PATTERN = new RegExp(
    "(" + ACTIVITY_VERBS.join("|") + ")\\s+(?:file|directory)\\s+(\\/[A-Za-z0-9_./+\\-@~%]+)",
    "g"
  );
  const ACTIVITY_VERB_SPLIT = new RegExp("(" + ACTIVITY_VERBS.join("|") + ")");
  const ACTIVITY_VERB_LABEL = {
    Updated: "更新",
    Created: "新建",
    Read: "读取",
    Wrote: "写入",
    Modified: "修改",
    Deleted: "删除",
    Listed: "列出",
  };

  function extractActivity(source) {
    const items = [];
    const text = source || "";
    const out = [];
    let cursor = 0;
    const pattern = new RegExp(ACTIVITY_PATTERN.source, "g");
    let m;
    while ((m = pattern.exec(text)) !== null) {
      const matchStart = m.index;
      const matchEnd = pattern.lastIndex;
      const verb = m[1];
      const rawPath = m[2];
      let path = rawPath;
      let consumed = matchEnd;
      const split = rawPath.slice(1).search(ACTIVITY_VERB_SPLIT);
      if (split >= 0) {
        path = rawPath.slice(0, split + 1);
        consumed = matchEnd - (rawPath.length - path.length);
        pattern.lastIndex = consumed;
      }
      path = path.replace(/[).,;:]+$/, "");
      if (path && path.length > 1) items.push({ verb, path });
      out.push(text.slice(cursor, matchStart));
      cursor = consumed;
    }
    out.push(text.slice(cursor));
    const cleanText = out
      .join("")
      .replace(/[ \t]+([。，；,;.])/g, "$1")
      .replace(/[ \t]{2,}/g, " ")
      .replace(/\n[ \t]+/g, "\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
    return { cleanText, items };
  }

  function renderAssistantBody(assistant, source) {
    const { cleanText, items } = extractActivity(source || "");
    renderMarkdown(assistant.body, cleanText);
    if (assistant.activity) renderActivity(assistant.activity, items);
  }

  function renderActivity(container, items) {
    container.innerHTML = "";
    if (!items.length) {
      container.hidden = true;
      container.open = false;
      return;
    }
    container.hidden = false;
    const summary = document.createElement("summary");
    const title = document.createElement("span");
    title.textContent = "工作区活动";
    const pill = document.createElement("span");
    pill.className = "activity-pill";
    pill.textContent = `${items.length} 条`;
    summary.append(title, pill);
    const list = document.createElement("div");
    list.className = "activity-list";
    for (const item of items) {
      const row = document.createElement("div");
      row.className = "activity-row";
      const verb = document.createElement("b");
      verb.className = "activity-verb";
      verb.textContent = ACTIVITY_VERB_LABEL[item.verb] || item.verb;
      const path = document.createElement("code");
      path.className = "activity-path";
      path.textContent = item.path;
      row.append(verb, path);
      list.appendChild(row);
    }
    container.append(summary, list);
  }

  function makeStreamRenderer(assistant, intervalMs) {
    const interval = intervalMs || 120;
    let scheduled = false;
    let lastRenderedAt = 0;
    const flush = () => {
      scheduled = false;
      lastRenderedAt = Date.now();
      renderAssistantBody(assistant, assistant.rawText || "");
      renderWorkspace();
      scrollMessages();
    };
    return function scheduleStreamRender() {
      if (scheduled) return;
      const wait = Math.max(0, interval - (Date.now() - lastRenderedAt));
      scheduled = true;
      setTimeout(flush, wait);
    };
  }

  function appendTurn(role, text, opts) {
    el.emptyState.hidden = true;
    const wrap = document.createElement("article");
    wrap.className = `turn ${role === "user" ? "turn-user" : "turn-agent"}`;
    if (opts && opts.streaming) wrap.classList.add("streaming");
    if (opts && opts.messageId) wrap.dataset.messageId = opts.messageId;

    const avatar = document.createElement("div");
    avatar.className = "avatar" + (role === "user" ? " user" : "");
    avatar.textContent = role === "user" ? "你" : "AR";

    const bubble = document.createElement("div");
    bubble.className = "bubble" + (role === "user" ? " user" : "");
    const body = document.createElement("div");
    body.className = "message-body";

    if (role === "assistant") {
      const head = document.createElement("div");
      head.className = "agent-head";
      const name = document.createElement("p");
      name.className = "agent-name";
      name.textContent = agentName((opts && opts.agentId) || sessionAgentId(activeSession()));
      const status = document.createElement("span");
      status.className = "state";
      status.textContent = opts && opts.streaming ? "运行中" : opts && opts.status ? opts.status : "已完成";
      head.append(name, status);
      bubble.appendChild(head);
    }

    bubble.appendChild(body);

    let activity = null;
    if (role === "assistant") {
      activity = document.createElement("details");
      activity.className = "activity";
      activity.hidden = true;
      bubble.appendChild(activity);
    }

    let thinkingBlock = null;
    if (role === "assistant") {
      thinkingBlock = document.createElement("div");
      thinkingBlock.className = "thinking-block";
      thinkingBlock.hidden = true;
      bubble.insertBefore(thinkingBlock, body);
    }

    const result = {
      body,
      activity,
      thinkingBlock,
      messageId: opts && opts.messageId,
      trace: null,
      wrap,
      rawText: text || "",
    };

    if (role === "assistant" && opts && opts.streaming) {
      body.textContent = text || "";
    } else if (role === "assistant") {
      renderAssistantBody(result, text || "");
    } else {
      renderMarkdown(body, text || "");
    }

    if (role === "assistant" && opts && opts.trace) {
      result.trace = createTrace();
      bubble.appendChild(result.trace.root);
    }

    wrap.append(avatar, bubble);
    el.messages.appendChild(wrap);
    scrollMessages();
    return result;
  }



  function createTrace() {
    const root = document.createElement("details");
    root.className = "trace";
    root.open = true;
    const summary = document.createElement("summary");
    const title = document.createElement("span");
    title.textContent = "执行过程";
    const pill = document.createElement("span");
    pill.className = "trace-pill";
    pill.textContent = "0 步";
    const list = document.createElement("div");
    list.className = "trace-list";
    summary.append(title, pill);
    root.append(summary, list);
    const counters = { code: 0, steps: 0, tools: 0 };
    return {
      root,
      add(eventName, payload) {
        const step = classifyEvent(eventName, payload);
        counters.steps += 1;
        if (step.kind === "code") counters.code += 1;
        if (step.kind === "tool" || step.kind === "mcp" || step.kind === "api") counters.tools += 1;
        pill.textContent = `${counters.steps} 步 · ${counters.tools} tools · ${counters.code} code`;

        const row = document.createElement("div");
        row.className = "step";
        const dot = document.createElement("span");
        dot.className = `dot ${step.dot}`;
        const text = document.createElement("div");
        const label = document.createElement("b");
        label.textContent = step.title;
        const sub = document.createElement("span");
        sub.textContent = step.subtitle;
        const code = document.createElement("code");
        code.textContent = step.kind;
        text.append(label, sub);
        if (step.detail) text.appendChild(makeStepDetail(step.detail));
        row.append(dot, text, code);
        list.appendChild(row);
        scrollMessages();
      },
    };
  }

  function classifyEvent(eventName, payload) {
    const text = JSON.stringify(payload || {}).toLowerCase();
    let kind = eventName;
    if (text.includes("mcp")) kind = "mcp";
    else if (text.includes("api") || text.includes("http")) kind = "api";
    else if (text.includes("code") || text.includes("python") || text.includes("shell")) kind = "code";
    else if (eventName.includes("tool")) kind = "tool";
    const titleMap = {
      api: "调用 Runtime API",
      code: "执行代码",
      mcp: "调用 MCP",
      policy_denied: "策略拒绝",
      task_cancelled: "任务已取消",
      task_completed: "任务已完成",
      task_failed: "任务失败",
      task_started: "任务已启动",
      tool: "工具调用",
      task_waiting: "等待用户输入",
    };
    const fallbackTitle = titleMap[kind] || titleMap[eventName] || eventName;
    return {
      dot: eventName.includes("failed") || eventName.includes("denied") ? "danger" : eventName.includes("completed") ? "ok" : kind,
      kind,
      subtitle: summarizePayload(payload),
      title: fallbackTitle,
      detail: errorPayloadDetail(eventName, payload, fallbackTitle),
    };
  }

  function makeStepDetail(detail) {
    const node = document.createElement("details");
    node.className = "step-payload";
    node.open = true;
    const summary = document.createElement("summary");
    summary.textContent = "完整错误";
    const pre = document.createElement("pre");
    pre.textContent = detail;
    node.append(summary, pre);
    return node;
  }

  function errorPayloadDetail(eventName, payload, fallback) {
    if (!eventName.includes("failed") && !eventName.includes("denied")) return "";
    return formatTaskError(payload && (payload.error || payload), fallback);
  }

  function summarizePayload(payload) {
    if (!payload || typeof payload !== "object") return "";
    if (payload.error) return errorSummary(formatTaskError(payload.error), "任务失败");
    const candidates = [
      payload.name,
      payload.tool_name,
      payload.server,
      payload.url,
      payload.message,
      payload.prompt,
      payload.task_id,
      payload.status,
    ].filter(Boolean);
    if (candidates.length) return candidates.join(" · ");
    try {
      return JSON.stringify(payload).slice(0, 120);
    } catch {
      return "";
    }
  }

  function buildTaskBody(session, input) {
    return {
      agent_id: sessionAgentId(session) || selectedAgentId(),
      input,
      mode: el.mode.value === "durable" ? "durable" : "one_shot",
      session_id: session.sessionId,
    };
  }

  async function sendTask() {
    const input = el.userInput.value.trim();
    if (!input || state.busy) return;
    showError("");
    const session = await ensureSession();
    const userMessage = appendStoredMessage(session.sessionId, { role: "user", text: input });
    appendTurn("user", input, { messageId: userMessage && userMessage.id });
    const assistantMessage = appendStoredMessage(session.sessionId, {
      agentId: sessionAgentId(session),
      role: "assistant",
      status: "streaming",
      text: "",
    });
    const assistant = appendTurn("assistant", "", {
      agentId: sessionAgentId(session),
      messageId: assistantMessage && assistantMessage.id,
      streaming: true,
      trace: true,
    });
    el.userInput.value = "";
    setBusy(true);
    setStatus("创建任务...");
    const task = await fetchJson("/tasks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(buildTaskBody(session, input)),
    });
    state.activeTaskId = task.task_id;
    setBusy(true);
    upsertSession({
      ...session,
      lastTaskId: task.task_id,
      mode: el.mode.value,
      status: task.status || "running",
      updatedAt: Date.now(),
      workspaceId: task.workspace_id || session.workspaceId || "",
    });
    renderSessions();
    renderWorkspace();
    attachStream(task.task_id, assistant, session.sessionId);
  }

  function attachStream(taskId, assistant, sessionId) {
    if (state.eventSource) state.eventSource.close();
    state.streamingSessionId = sessionId || state.activeSessionId;
    state.streamingAssistantMessageId = assistant.messageId || "";
    state.eventSource = new EventSource(`/tasks/${encodeURIComponent(taskId)}/stream`);
    const events = [
      "task_started",
      "tool_call_started",
      "tool_call_completed",
      "tool_call_failed",
      "policy_denied",
      "task_waiting",
      "task_completed",
      "task_failed",
      "task_cancelled",
    ];
    for (const name of events) {
      state.eventSource.addEventListener(name, (event) => handleRuntimeEvent(name, event, assistant, taskId, sessionId));
    }
    state.eventSource.addEventListener("model_thinking", (event) => {
      const data = readEvent(event);
      // 子Agent的thinking不污染父Agent的消息气泡
      if (data.langgraph_namespace && data.langgraph_namespace.length > 0) return;
      const payload = data.payload || {};
      const text =
        typeof payload.text === "string"
          ? payload.text
          : typeof payload.reasoning === "string"
            ? payload.reasoning
            : typeof payload.reasoning_content === "string"
              ? payload.reasoning_content
              : typeof payload.thinking === "string"
                ? payload.thinking
                : "";
      if (!text) return;
      if (assistant.thinkingBlock) {
        assistant.thinkingBlock.hidden = false;
        assistant.thinkingBlock.textContent += text;
      }
    });
    const scheduleStreamRender = makeStreamRenderer(assistant);
    state.eventSource.addEventListener("message_delta", (event) => {
      const data = readEvent(event);
      // 忽略子Agent的消息增量，只累积根Agent的输出
      if (data.langgraph_namespace && data.langgraph_namespace.length > 0) return;
      if ((data.payload || {}).content_type === "reasoning") return;
      const delta = deltaText(data.payload);
      if (!delta) return;
      assistant.rawText = (assistant.rawText || "") + delta;
      if (assistant.messageId) {
        upsertStoredMessage(sessionId, assistant.messageId, {
          status: "streaming",
          text: assistant.rawText,
        });
      }
      scheduleStreamRender();
    });
    state.eventSource.onerror = () => {
      showError("SSE 连接中断，请重试。");
      finishAssistant(assistant, "连接中断", sessionId);
    };
  }

  function handleRuntimeEvent(name, event, assistant, taskId, sessionId) {
    const data = readEvent(event);
    // 忽略子Agent的事件——不记录trace、不触发生命周期操作
    if (data.langgraph_namespace && data.langgraph_namespace.length > 0) return;
    if (assistant.trace) {
      assistant.trace.add(name, data.payload || {});
      // 持久化trace事件到assistant，用于刷新后恢复
      if (!assistant._traceEvents) assistant._traceEvents = [];
      if (assistant._traceEvents.length < 200) {
        assistant._traceEvents.push({ name: name, payload: data.payload || {}, ts: Date.now() });
      }
    }
    if (name === "task_started") setStatus("运行中...");
    if (name === "task_waiting") {
      const payload = data.payload || {};
      finishAssistant(assistant, "等待输入", sessionId);
      state.waitingTaskId = taskId;
      upsertActiveTaskStatus(["waiting", "input"].join("_"));
      el.waitingTitle.textContent = payload.prompt || payload.message || "需要你的输入";
      el.waitingPanel.classList.remove("hidden");
      el.waitingInput.focus();
    }
    if (name === "task_completed") {
      const finalOutput = formatFinalOutput(data.payload && data.payload.final_output);
      if (finalOutput && !(assistant.rawText || "").trim()) assistant.rawText = finalOutput;
      if (!(assistant.rawText || "").trim()) {
        assistant.rawText = "任务已完成，可在左侧工作区查看产出物。";
      }
      finishAssistant(assistant, "已完成", sessionId);
      upsertActiveTaskStatus("completed");
    }
    if (name === "task_failed" || name === "policy_denied") {
      const payload = data.payload || {};
      const fallback = name === "policy_denied" ? "策略拒绝" : "任务失败";
      const errorText = formatTaskError(payload.error || payload, fallback);
      showError(errorSummary(errorText, fallback));
      assistant.rawText = appendAssistantError(assistant.rawText || "", errorText);
      finishAssistant(assistant, fallback, sessionId);
      upsertActiveTaskStatus("failed");
    }
    if (name === "task_cancelled") {
      // 忽略子Agent的取消事件，只处理根级事件
      if (data.langgraph_namespace && data.langgraph_namespace.length > 0) return;
      if (!(assistant.rawText || "").trim()) assistant.rawText = "已取消";
      finishAssistant(assistant, "已取消", sessionId);
      upsertActiveTaskStatus("cancelled");
    }
  }

  function finishAssistant(assistant, statusText, sessionId) {
    if (state.eventSource) {
      state.eventSource.close();
      state.eventSource = null;
    }
    const finalText = assistant.rawText && assistant.rawText.length
      ? assistant.rawText
      : assistant.body.textContent;
    assistant.rawText = finalText;
    renderAssistantBody(assistant, finalText);
    if (assistant.messageId) {
      upsertStoredMessage(sessionId || state.activeSessionId, assistant.messageId, {
        status: statusText || "已完成",
        text: finalText,
      });
      // 持久化trace事件
      if (assistant._traceEvents && assistant._traceEvents.length) {
        saveStoredTrace(sessionId || state.activeSessionId, assistant.messageId, assistant._traceEvents);
      }
    }
    const stateEl = assistant.wrap.querySelector(".state");
    if (stateEl) stateEl.textContent = statusText || "已完成";
    assistant.wrap.classList.remove("streaming");
    state.activeTaskId = "";
    state.streamingAssistantMessageId = "";
    state.streamingSessionId = "";
    setBusy(false);
    setStatus(statusText || "idle");
    scrollMessages();
  }

  function upsertActiveTaskStatus(status) {
    const session = activeSession();
    if (session) {
      upsertSession({ ...session, status, updatedAt: Date.now() });
      renderSessions();
      renderWorkspace();
    }
  }

  function readEvent(event) {
    try {
      return JSON.parse(event.data);
    } catch {
      return { payload: { raw: event.data } };
    }
  }

  function deltaText(payload) {
    if (!payload || typeof payload !== "object") return "";
    if (typeof payload.delta === "string") return payload.delta;
    if (typeof payload.text === "string") return payload.text;
    if (payload.delta && typeof payload.delta.content === "string") return payload.delta.content;
    return "";
  }

  function formatFinalOutput(value) {
    if (value == null) return "";
    if (typeof value === "string") return value;
    return JSON.stringify(value, null, 2);
  }

  function formatTaskError(error, fallback) {
    if (!error) return fallback || "任务失败";
    if (typeof error === "string") return error;
    const lines = [fallback || "任务失败", ""];
    if (error.type) lines.push(`- type: ${error.type}`);
    if (error.category) lines.push(`- category: ${error.category}`);
    if (error.module) lines.push(`- module: ${error.module}`);
    if (error.retryable != null) lines.push(`- retryable: ${String(error.retryable)}`);
    if (error.message || error.detail) {
      lines.push("", error.message || error.detail);
    }
    const details = error.details || error.extra || error.context;
    if (details != null) {
      lines.push("", "details:", "```json", JSON.stringify(details, null, 2), "```");
    }
    return lines.filter((line, index) => line !== "" || lines[index - 1] !== "").join("\n");
  }

  function appendAssistantError(current, errorText) {
    const body = (current || "").trim();
    const errorBody = (errorText || "任务失败").trim();
    if (!body) return errorBody;
    if (body.includes(errorBody)) return body;
    return `${body}\n\n---\n\n${errorBody}`;
  }

  function errorSummary(errorText, fallback) {
    const lines = String(errorText || "")
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean);
    const message = lines.find((line) => !line.startsWith("- ") && line !== fallback);
    return message || fallback || "任务失败";
  }

  async function resumeTask() {
    const input = el.waitingInput.value.trim();
    if (!input || !state.waitingTaskId) return;
    const session = activeSession();
    if (!session) return;
    showError("");
    const userMessage = appendStoredMessage(session.sessionId, { role: "user", text: input });
    appendTurn("user", input, { messageId: userMessage && userMessage.id });
    const assistantMessage = appendStoredMessage(session.sessionId, {
      agentId: sessionAgentId(session),
      role: "assistant",
      status: "streaming",
      text: "",
    });
    const assistant = appendTurn("assistant", "", {
      agentId: sessionAgentId(session),
      messageId: assistantMessage && assistantMessage.id,
      streaming: true,
      trace: true,
    });
    const taskId = state.waitingTaskId;
    state.waitingTaskId = "";
    el.waitingInput.value = "";
    el.waitingPanel.classList.add("hidden");
    setBusy(true);
    await fetchJson(`/tasks/${encodeURIComponent(taskId)}/resume`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ input }),
    });
    state.activeTaskId = taskId;
    upsertSession({ ...session, lastTaskId: taskId, status: "running", updatedAt: Date.now() });
    renderSessions();
    renderWorkspace();
    attachStream(taskId, assistant, session.sessionId);
  }

  async function cancelTask() {
    if (!state.activeTaskId) return;
    await fetchJson(`/tasks/${encodeURIComponent(state.activeTaskId)}/cancel`, { method: "POST" });
    setStatus("取消中...");
  }

  function scrollMessages() {
    el.messages.scrollTop = el.messages.scrollHeight;
  }

  function bindEvents() {
    el.newSession.addEventListener("click", () => run(createSession));
    el.refreshSessions.addEventListener("click", () => run(refreshRemoteSessions));
    el.sessionFilter.addEventListener("input", () => {
      state.filter = el.sessionFilter.value;
      renderSessions();
    });
    el.agentSelect.addEventListener("change", () => {
      updateActiveSession({ agentId: selectedAgentId() });
      syncLabels();
    });
    el.mode.addEventListener("change", () => {
      updateActiveSession({ mode: el.mode.value });
      syncLabels();
    });
    el.send.addEventListener("click", () => run(sendTask));
    el.userInput.addEventListener("keydown", submitOnEnter(sendTask));
    el.cancel.addEventListener("click", () => run(cancelTask));
    el.resume.addEventListener("click", () => run(resumeTask));
    el.waitingInput.addEventListener("keydown", submitOnEnter(resumeTask));
  }

  function submitOnEnter(action) {
    return (event) => {
      if (event.key !== "Enter") return;
      if (event.isComposing || event.keyCode === 229) return;
      if (event.shiftKey) return;
      event.preventDefault();
      run(action);
    };
  }

  async function run(fn) {
    try {
      await fn();
    } catch (error) {
      showError(error && error.message ? error.message : String(error));
      setBusy(false);
    }
  }

  async function init() {
    bindEvents();
    // 第一步：渲染本地数据（不依赖任何远程API）
    renderSessions();
    if (state.activeSessionId) {
      applySessionControls(activeSession());
      renderStoredMessages(state.activeSessionId);
      syncLabels();
    } else if (state.sessions[0]) {
      setActiveSessionId(state.sessions[0].sessionId);
      applySessionControls(activeSession());
      renderStoredMessages(state.activeSessionId);
      syncLabels();
    } else {
      syncLabels();
    }
    // 第二步：加载Agent列表（阻塞，关键UI）
    await loadAgents().catch(() => undefined);
    // 第三步：异步同步远程数据（失败不影响本地渲染）
    refreshRemoteSessions().catch(() => undefined);
  }

  document.addEventListener("DOMContentLoaded", () => {
    run(init);
  });
})();
