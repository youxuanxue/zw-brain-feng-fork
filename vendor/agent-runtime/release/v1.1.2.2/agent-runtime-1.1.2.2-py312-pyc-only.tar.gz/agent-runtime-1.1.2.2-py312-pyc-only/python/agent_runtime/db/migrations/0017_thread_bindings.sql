-- Unified session runtime model: per (session_id, agent_id) active thread binding.

CREATE TABLE IF NOT EXISTS thread_bindings (
    binding_id UUID PRIMARY KEY,
    session_id UUID NOT NULL,
    agent_id TEXT NOT NULL,
    deepagents_thread_id TEXT NOT NULL,
    scope TEXT NOT NULL DEFAULT 'session_agent',
    workspace_id TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS thread_bindings_active_session_agent_uq
    ON thread_bindings (session_id, agent_id)
    WHERE status = 'active';

CREATE INDEX IF NOT EXISTS thread_bindings_session_id_idx
    ON thread_bindings (session_id);
