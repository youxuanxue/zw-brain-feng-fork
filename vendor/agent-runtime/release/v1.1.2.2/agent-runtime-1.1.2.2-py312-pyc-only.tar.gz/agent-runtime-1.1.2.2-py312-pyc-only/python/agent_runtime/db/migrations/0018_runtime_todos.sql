CREATE TABLE IF NOT EXISTS runtime_todos (
    task_id UUID PRIMARY KEY,
    todos JSONB NOT NULL DEFAULT '[]'::jsonb,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
