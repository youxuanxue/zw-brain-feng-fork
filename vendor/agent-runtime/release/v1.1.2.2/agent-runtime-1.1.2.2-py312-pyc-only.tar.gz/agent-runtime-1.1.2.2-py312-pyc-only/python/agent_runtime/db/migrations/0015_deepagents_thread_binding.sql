ALTER TABLE tasks
    ADD COLUMN IF NOT EXISTS deepagents_thread_id TEXT,
    ADD COLUMN IF NOT EXISTS thread_binding_id UUID;

CREATE INDEX IF NOT EXISTS tasks_deepagents_thread_idx
    ON tasks(deepagents_thread_id)
    WHERE deepagents_thread_id IS NOT NULL;
