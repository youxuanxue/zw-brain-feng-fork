/**
 * SSE：GET /tasks/{id}/stream → RuntimeEvent
 */
(function (w) {
  "use strict";

  function extractDeltaText(payload) {
    if (!payload || typeof payload !== "object") return "";
    if (typeof payload.delta === "string") return payload.delta;
    if (typeof payload.text === "string") return payload.text;
    if (payload.delta && typeof payload.delta.content === "string") return payload.delta.content;
    return "";
  }

  function formatFinalOutput(out) {
    if (out == null) return "";
    if (typeof out === "string") return out;
    try {
      return JSON.stringify(out, null, 2);
    } catch {
      return String(out);
    }
  }

  function readEventData(ev) {
    try {
      return JSON.parse(ev.data);
    } catch {
      return { payload: { raw: ev.data } };
    }
  }

  function waitingPromptFromPayload(payload) {
    const p = payload || {};
    const details = p.details || {};
    return (
      p.prompt ||
      p.question ||
      details.prompt ||
      details.question ||
      p.display_message ||
      details.display_message ||
      p.message ||
      "请补充输入后继续。"
    );
  }

  function note(h, eventName, payload, assistantWrap) {
    if (!h.addTimelineEvent) return null;
    const row = h.addTimelineEvent(eventName, payload || {});
    return row;
  }

  /**
   * @param {string} streamUrl full URL to task stream
   * @param {object} h handlers: assistantBody, assistantWrap, appendToolLine, setStatus, showError,
   *   onFinal (no args), onWaitingInput(taskId, prompt)
   */
  w.attachTaskEventSource = function (streamUrl, h) {
    const es = new EventSource(streamUrl);
    const assistantBody = h.assistantBody;
    const assistantWrap = h.assistantWrap;
    let _closedNormally = false;

    const onFinal = () => {
      if (_closedNormally) return;
      _closedNormally = true;
      assistantWrap.classList.remove("msg-streaming");
      const plain = assistantBody.textContent;
      if (h.onStreamFinal) h.onStreamFinal(plain);
      if (h.renderMdBody) h.renderMdBody(assistantBody, plain);
      h.setBusy(false);
      h.setActiveTaskId(null);
      es.close();
      if (h.focusComposer) h.focusComposer();
    };

    es.addEventListener("task_started", (ev) => {
      const data = readEventData(ev);
      note(h, "task_started", data.payload || {}, assistantWrap);
      h.setStatus("运行中…");
    });

    es.addEventListener("message_delta", (ev) => {
      try {
        const data = JSON.parse(ev.data);
        if ((data.payload || {}).content_type === "reasoning") return;
        const piece = extractDeltaText(data.payload);
        if (piece) assistantBody.textContent += piece;
        if (h.scrollMessages) h.scrollMessages();
      } catch {
        /* ignore */
      }
    });

    es.addEventListener("tool_call_started", (ev) => {
      const data = readEventData(ev);
      const row = note(h, "tool_call_started", data.payload || {}, assistantWrap);
      if (!row) h.appendToolLine(assistantWrap, "工具调用");
    });

    es.addEventListener("tool_call_completed", (ev) => {
      const data = readEventData(ev);
      const row = note(h, "tool_call_completed", data.payload || {}, assistantWrap);
      if (!row) h.appendToolLine(assistantWrap, "工具结果");
    });

    es.addEventListener("tool_call_failed", (ev) => {
      const data = readEventData(ev);
      const row = note(h, "tool_call_failed", data.payload || {}, assistantWrap);
      if (!row) h.appendToolLine(assistantWrap, "工具失败");
    });

    es.addEventListener("task_completed", (ev) => {
      try {
        const data = readEventData(ev);
        // 忽略子Agent的completed事件，只处理根级任务完成
        if (data.langgraph_namespace && data.langgraph_namespace.length > 0) return;
        const fin = data.payload && data.payload.final_output;
        const formatted = formatFinalOutput(fin);
        if (formatted && !assistantBody.textContent.trim()) assistantBody.textContent = formatted;
        note(h, "task_completed", data.payload || {}, null);
      } catch {
        /* ignore */
      }
      h.setStatus("已完成");
      h.showError("");
      onFinal();
    });

    es.addEventListener("task_failed", (ev) => {
      let msg = "任务失败";
      let payload = {};
      try {
        const data = readEventData(ev);
        // 忽略子Agent的失败事件，只处理根级事件
        if (data.langgraph_namespace && data.langgraph_namespace.length > 0) return;
        payload = data.payload || {};
        const err = payload.error;
        if (err && err.message) msg = err.message;
        else if (err && err.type) msg = err.type;
      } catch {
        /* ignore */
      }
      note(h, "task_failed", payload, assistantWrap);
      h.showError(msg);
      h.appendToolLine(assistantWrap, msg);
      h.setStatus("");
      onFinal();
    });

    es.addEventListener("task_cancelled", (ev) => {
      const data = readEventData(ev);
      // 忽略子Agent的取消事件，只处理根级事件
      if (data.langgraph_namespace && data.langgraph_namespace.length > 0) return;
      note(h, "task_cancelled", data.payload || {}, assistantWrap);
      h.appendToolLine(assistantWrap, "已取消");
      h.setStatus("");
      onFinal();
    });

    es.addEventListener("task_waiting", (ev) => {
      let prompt = "请补充输入后继续。";
      let payload = {};
      let data = { task_id: h.taskId, payload };
      try {
        data = readEventData(ev);
        payload = data.payload || {};
        prompt = waitingPromptFromPayload(payload);
      } catch {
        /* ignore */
      }
      const taskId = data.task_id || h.taskId;
      note(h, "task_waiting", payload, assistantWrap);
      _closedNormally = true;
      /* 先清除 onerror，避免 es.close() 在部分浏览器中触发 onerror 导致错误提示 */
      es.onerror = null;
      assistantWrap.classList.remove("msg-streaming");
      const plainWait = assistantBody.textContent;
      if (h.onStreamFinal) h.onStreamFinal(plainWait);
      if (h.renderMdBody) h.renderMdBody(assistantBody, plainWait);
      h.setBusy(false);
      h.setActiveTaskId(null);
      es.close();
      if (h.onWaitingInput) h.onWaitingInput(taskId, prompt, payload, data);
    });

    es.addEventListener("policy_denied", (ev) => {
      let msg = "策略拒绝";
      let payload = {};
      try {
        const data = readEventData(ev);
        payload = data.payload || {};
        msg = JSON.stringify(payload).slice(0, 300);
      } catch {
        /* ignore */
      }
      note(h, "policy_denied", payload, assistantWrap);
      h.showError(msg);
      h.appendToolLine(assistantWrap, msg);
      onFinal();
    });

    es.onerror = () => {
      /* 三种场景静默忽略：
       *  1) _closedNormally 已在 task_waiting 中被设置
       *  2) readyState 为 CLOSED (2) 且 _closedNormally 标识已设
       *  3) 浏览器已在 task_waiting 事件之前关闭了连接（readyState === CLOSED）
       */
      if (_closedNormally) return;
      if (es.readyState === EventSource.CLOSED) return;
      h.showError("连接中断，请重试或检查网络与代理（SSE）。");
      onFinal();
    };

    return es;
  };
})(typeof window !== "undefined" ? window : globalThis);
