CREATE TABLE IF NOT EXISTS sessions (
    session_id UUID PRIMARY KEY,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    trust_level TEXT NOT NULL CHECK (trust_level IN ('platform','verified','untrusted')),
    workspace_id TEXT,
    title TEXT,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived','deleted')),
    created_at TIMESTAMPTZ NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL
);

CREATE INDEX IF NOT EXISTS sessions_metadata_gin ON sessions USING GIN (metadata);

CREATE TABLE IF NOT EXISTS tasks (
    task_id UUID PRIMARY KEY,
    session_id UUID NOT NULL REFERENCES sessions(session_id) ON DELETE CASCADE,
    agent_id TEXT NOT NULL,
    agent_manifest_snapshot JSONB NOT NULL,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    effective_trust TEXT NOT NULL CHECK (effective_trust IN ('platform','verified','untrusted')),
    workspace_id TEXT NOT NULL,
    run_kind TEXT NOT NULL DEFAULT 'session_run'
        CHECK (run_kind IN ('session_run','scheduled_run','manual_shortcut')),
    persistence TEXT NOT NULL DEFAULT 'session'
        CHECK (persistence IN ('none','session','persisted')),
    status TEXT NOT NULL CHECK (
        status IN ('pending','running','waiting_input','completed','failed','cancelled')
    ),
    input_summary TEXT,
    final_output JSONB,
    error JSONB,
    started_at TIMESTAMPTZ,
    finished_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS tasks_session_started_idx ON tasks(session_id, started_at);

CREATE TABLE IF NOT EXISTS task_events (
    id BIGSERIAL PRIMARY KEY,
    task_id UUID NOT NULL REFERENCES tasks(task_id) ON DELETE CASCADE,
    agent_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    payload JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL
);

CREATE INDEX IF NOT EXISTS task_events_task_created_idx ON task_events(task_id, id);
