/**
 * 浏览器侧会话索引与消息持久化（localStorage），与 GET/POST /sessions 互补。
 */
(function (w) {
  "use strict";

  const INDEX_KEY = "ar_chat_sessions_index_v1";
  const CURRENT_KEY = "ar_chat_current_session_v1";
  const MSG_PREFIX = "ar_chat_msgs:";
  const EVENT_PREFIX = "ar_chat_events:";

  function safeParse(json, fallback) {
    try {
      const v = JSON.parse(json);
      return v != null ? v : fallback;
    } catch {
      return fallback;
    }
  }

  w.chatStorage = {
    getCurrentSessionId() {
      return localStorage.getItem(CURRENT_KEY);
    },
    setCurrentSessionId(id) {
      if (id) localStorage.setItem(CURRENT_KEY, id);
      else localStorage.removeItem(CURRENT_KEY);
    },

    loadIndex() {
      return safeParse(localStorage.getItem(INDEX_KEY) || "[]", []);
    },

    saveIndex(entries) {
      localStorage.setItem(INDEX_KEY, JSON.stringify(entries));
    },

    upsertEntry(entry) {
      const list = w.chatStorage.loadIndex();
      const i = list.findIndex((e) => e.sessionId === entry.sessionId);
      const merged = {
        createdAt: Date.now(),
        agentId: null,
        ...list[i],
        ...entry,
        updatedAt: entry.updatedAt != null ? entry.updatedAt : Date.now(),
      };
      if (i >= 0) list[i] = merged;
      else list.unshift(merged);
      w.chatStorage.saveIndex(list);
      return list;
    },

    removeEntry(sessionId) {
      const list = w.chatStorage.loadIndex().filter((e) => e.sessionId !== sessionId);
      w.chatStorage.saveIndex(list);
      localStorage.removeItem(MSG_PREFIX + sessionId);
      localStorage.removeItem(EVENT_PREFIX + sessionId);
      return list;
    },

    getEvents(sessionId) {
      return safeParse(localStorage.getItem(EVENT_PREFIX + sessionId) || "[]", []);
    },

    setEvents(sessionId, events) {
      localStorage.setItem(EVENT_PREFIX + sessionId, JSON.stringify(events));
    },

    getMessages(sessionId) {
      return safeParse(localStorage.getItem(MSG_PREFIX + sessionId) || "[]", []);
    },

    setMessages(sessionId, messages) {
      localStorage.setItem(MSG_PREFIX + sessionId, JSON.stringify(messages));
    },

    appendMessage(sessionId, msg) {
      const arr = w.chatStorage.getMessages(sessionId);
      arr.push({ ...msg, ts: msg.ts || Date.now() });
      w.chatStorage.setMessages(sessionId, arr);
      return arr;
    },

    touchSession(sessionId, patch, opts) {
      opts = opts || {};
      const list = w.chatStorage.loadIndex();
      const i = list.findIndex((e) => e.sessionId === sessionId);
      if (i < 0) return list;
      const next = { ...list[i], ...patch };
      if (!opts.preserveUpdatedAt) next.updatedAt = Date.now();
      list[i] = next;
      w.chatStorage.saveIndex(list);
      return list;
    },
  };
})(typeof window !== "undefined" ? window : globalThis);
