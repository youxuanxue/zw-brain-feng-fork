-- Spec 2026-05-06 §10 — Persist resolved middleware snapshot per Task.
-- The snapshot is the audit/resume source of truth for which middleware
-- and limits were active when the Task started. Stored as JSONB; never
-- contains secrets or raw policy text (only checksums).

ALTER TABLE tasks
    ADD COLUMN IF NOT EXISTS middleware_snapshot JSONB;
