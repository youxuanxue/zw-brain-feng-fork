ALTER TABLE sessions
    ADD COLUMN IF NOT EXISTS last_task_id UUID,
    ADD COLUMN IF NOT EXISTS last_agent_id TEXT,
    ADD COLUMN IF NOT EXISTS last_task_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS sessions_last_agent_idx ON sessions(last_agent_id);
CREATE INDEX IF NOT EXISTS sessions_last_task_at_idx ON sessions(last_task_at DESC NULLS LAST);

UPDATE sessions s
SET last_task_id = sub.task_id,
    last_agent_id = sub.agent_id,
    last_task_at = sub.started_at
FROM (
    SELECT DISTINCT ON (session_id)
        session_id,
        task_id,
        agent_id,
        started_at
    FROM tasks
    ORDER BY session_id, started_at DESC NULLS LAST, task_id DESC
) AS sub
WHERE s.session_id = sub.session_id
  AND s.last_task_id IS NULL;
