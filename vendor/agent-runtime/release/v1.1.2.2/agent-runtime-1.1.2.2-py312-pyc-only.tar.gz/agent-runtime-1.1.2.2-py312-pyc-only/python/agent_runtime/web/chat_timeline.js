(function (w) {
  "use strict";

  const TYPE_LABELS = {
    task: "Task",
    model: "Model",
    tool: "Tool",
    skill: "Skill",
    mcp: "MCP",
    api: "API",
    code: "Code",
    policy: "Policy",
    waiting: "Input",
    result: "Result",
    error: "Error",
  };

  function asJson(value) {
    try {
      return JSON.stringify(value, null, 2);
    } catch {
      return String(value);
    }
  }

  function compactJson(value, max) {
    const s = typeof value === "string" ? value : asJson(value);
    return s.length > max ? s.slice(0, max) + "…" : s;
  }

  function payloadText(payload) {
    if (!payload || typeof payload !== "object") return String(payload || "");
    const keys = ["name", "tool", "tool_name", "skill", "skill_name", "server", "url", "command", "source"];
    for (const k of keys) {
      if (typeof payload[k] === "string" && payload[k]) return payload[k];
    }
    return "";
  }

  function classify(eventName, payload) {
    const text = (eventName + " " + compactJson(payload || {}, 500)).toLowerCase();
    if (eventName === "policy_denied") return "policy";
    if (eventName === "task_waiting") return "waiting";
    if (eventName === "task_failed") return "error";
    if (eventName === "task_completed") return "result";
    if (eventName === "task_started" || eventName === "task_cancelled") return "task";
    if (eventName === "message_delta") return "model";
    if (text.includes("skill")) return "skill";
    if (text.includes("mcp") || text.includes("callmcptool")) return "mcp";
    if (/\b(api|http|fetch|request|response|get|post|patch|delete)\b/.test(text)) return "api";
    if (/\b(code|python|shell|bash|command|execute|sandbox|terminal)\b/.test(text)) return "code";
    return "tool";
  }

  function titleFor(eventName, kind, payload) {
    const named = payloadText(payload);
    if (eventName === "task_started") return "任务已启动";
    if (eventName === "task_completed") return "任务完成";
    if (eventName === "task_failed") return "任务失败";
    if (eventName === "task_cancelled") return "任务取消";
    if (eventName === "task_waiting") return "等待用户输入";
    if (eventName === "policy_denied") return "策略拒绝";
    if (eventName === "tool_call_completed") return (TYPE_LABELS[kind] || "Tool") + " 返回结果";
    if (eventName === "tool_call_failed") return (TYPE_LABELS[kind] || "Tool") + " 调用失败";
    return (TYPE_LABELS[kind] || "Tool") + (named ? " · " + named : " 调用");
  }

  w.createChatTimeline = function (els) {
    const listEl = els.list;
    const statTotal = els.statTotal;
    const statTool = els.statTool;
    const statCode = els.statCode;
    const onRender = els.onRender;
    let rows = [];

    function updateStats() {
      if (statTotal) statTotal.textContent = rows.length + " 步";
      if (statTool)
        statTool.textContent = rows.filter((r) => ["tool", "skill", "mcp", "api"].includes(r.kind)).length + " tools";
      if (statCode) statCode.textContent = rows.filter((r) => r.kind === "code").length + " code";
    }

    function render() {
      listEl.innerHTML = "";
      if (!rows.length) {
        const empty = document.createElement("li");
        empty.className = "run-empty";
        empty.textContent = "发送消息后，这里会显示 task、skill、MCP、API、tool 和代码执行过程。";
        listEl.appendChild(empty);
        updateStats();
        return;
      }
      for (const row of rows) {
        const li = document.createElement("li");
        li.className = "run-step run-step-" + row.kind;
        const head = document.createElement("div");
        head.className = "run-step-head";
        const title = document.createElement("div");
        title.className = "run-step-title";
        title.textContent = row.title;
        const kind = document.createElement("div");
        kind.className = "run-step-kind";
        kind.textContent = TYPE_LABELS[row.kind] || row.kind;
        head.appendChild(title);
        head.appendChild(kind);
        const meta = document.createElement("div");
        meta.className = "run-step-meta";
        meta.textContent = row.time + " · " + row.event;
        li.appendChild(head);
        li.appendChild(meta);
        if (row.detail) {
          const body = document.createElement("pre");
          body.className = "run-step-body";
          body.textContent = row.detail;
          li.appendChild(body);
        }
        listEl.appendChild(li);
      }
      listEl.scrollTop = listEl.scrollHeight;
      updateStats();
      if (onRender) onRender();
    }

    function add(eventName, payload) {
      const kind = classify(eventName, payload);
      const row = {
        event: eventName,
        kind,
        title: titleFor(eventName, kind, payload),
        detail: payload ? compactJson(payload, 1200) : "",
        time: new Date().toLocaleTimeString("zh-CN", { hour12: false }),
      };
      rows.push(row);
      if (rows.length > 80) rows = rows.slice(rows.length - 80);
      render();
      return row;
    }

    function clear() {
      rows = [];
      render();
    }

    render();
    return { add, clear };
  };
})(typeof window !== "undefined" ? window : globalThis);
