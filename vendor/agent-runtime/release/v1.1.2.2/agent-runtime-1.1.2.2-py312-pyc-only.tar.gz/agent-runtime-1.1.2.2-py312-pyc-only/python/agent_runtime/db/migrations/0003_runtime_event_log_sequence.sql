ALTER TABLE task_events
    ADD COLUMN IF NOT EXISTS event_id TEXT,
    ADD COLUMN IF NOT EXISTS sequence BIGINT,
    ADD COLUMN IF NOT EXISTS session_id UUID,
    ADD COLUMN IF NOT EXISTS workspace_id TEXT,
    ADD COLUMN IF NOT EXISTS langgraph_thread_id TEXT,
    ADD COLUMN IF NOT EXISTS langgraph_namespace JSONB NOT NULL DEFAULT '[]'::jsonb;

WITH numbered AS (
    SELECT
        id,
        ROW_NUMBER() OVER (PARTITION BY task_id ORDER BY id) AS seq
    FROM task_events
)
UPDATE task_events e
SET
    sequence = numbered.seq,
    event_id = COALESCE(e.event_id, 'evt_pg_' || e.id::text)
FROM numbered
WHERE e.id = numbered.id
  AND (e.sequence IS NULL OR e.event_id IS NULL);

ALTER TABLE task_events
    ALTER COLUMN event_id SET NOT NULL,
    ALTER COLUMN sequence SET NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS task_events_task_sequence_idx
    ON task_events(task_id, sequence);

CREATE INDEX IF NOT EXISTS task_events_event_id_idx
    ON task_events(event_id);
