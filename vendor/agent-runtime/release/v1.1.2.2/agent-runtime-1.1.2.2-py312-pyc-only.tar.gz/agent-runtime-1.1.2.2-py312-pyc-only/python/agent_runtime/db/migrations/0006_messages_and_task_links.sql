-- Spec 2026-05-06 §Q4/§Q6 — MessageStore + Task<->Message linkage and idempotency.

CREATE TABLE IF NOT EXISTS messages (
    message_id TEXT PRIMARY KEY,
    session_id UUID NOT NULL REFERENCES sessions(session_id) ON DELETE CASCADE,
    task_id UUID REFERENCES tasks(task_id) ON DELETE SET NULL,
    agent_id TEXT,
    role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'tool_summary', 'system_status')),
    content_type TEXT NOT NULL DEFAULT 'text' CHECK (content_type IN ('text', 'structured')),
    content JSONB NOT NULL,
    resource_refs JSONB NOT NULL DEFAULT '[]'::jsonb,
    status TEXT NOT NULL DEFAULT 'final'
        CHECK (status IN ('final', 'failed', 'cancelled', 'waiting', 'streaming')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS messages_session_created_idx
    ON messages(session_id, created_at DESC, message_id DESC);

ALTER TABLE tasks
    ADD COLUMN IF NOT EXISTS input_message_id TEXT,
    ADD COLUMN IF NOT EXISTS output_message_id TEXT,
    ADD COLUMN IF NOT EXISTS idempotency_key TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS tasks_session_idempotency_key_uq
    ON tasks(session_id, idempotency_key)
    WHERE idempotency_key IS NOT NULL;
