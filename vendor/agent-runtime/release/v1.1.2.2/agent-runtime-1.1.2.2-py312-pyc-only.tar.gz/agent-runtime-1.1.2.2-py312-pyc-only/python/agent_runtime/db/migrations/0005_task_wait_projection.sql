-- Spec 2026-04-29 §7: persist a single active wait projection on the task row.
ALTER TABLE tasks
    ADD COLUMN IF NOT EXISTS wait_type TEXT
        CHECK (wait_type IN (
            'user_clarification',
            'external_result',
            'platform_recovery',
            'user_authorization'
        ));

ALTER TABLE tasks
    ADD COLUMN IF NOT EXISTS interrupt_payload JSONB;
