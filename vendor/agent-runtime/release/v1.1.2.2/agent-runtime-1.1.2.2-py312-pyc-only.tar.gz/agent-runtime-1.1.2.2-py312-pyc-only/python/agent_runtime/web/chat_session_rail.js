(function (w) {
  "use strict";

  /**
   * @param {object} o getSessionId,setSessionId,setWaitingTaskId,el,st,fetchJson,closeStream,persistMsgs,
   *   appendMessage,renderMdBody,showError,setStatus,LEGACY_SESSION
   */
  w.createChatSessionRail = function (o) {
    /** 下拉项文案为「名称 (agent_id)」，会话标题只取展示名称。 */
    function selectedAgentDisplayName() {
      const sel = o.el.agentSelect;
      const opt = sel.options[sel.selectedIndex];
      if (!opt) return "未选 Agent";
      const raw = opt.textContent.trim();
      if (!opt.value) return raw || "未选 Agent";
      const idx = raw.lastIndexOf(" (");
      if (idx > 0 && raw.endsWith(")")) return raw.slice(0, idx).trim();
      return raw;
    }

    function defaultSessionTitle() {
      const agentPart = selectedAgentDisplayName();
      const timePart = new Date().toLocaleString("zh-CN", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: false,
      });
      return agentPart + " · " + timePart;
    }

    function renderSessionList() {
      const sid = o.getSessionId();
      const list = o
        .st()
        .loadIndex()
        .slice()
        .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
      o.el.sessionList.innerHTML = "";
      for (const e of list) {
        const li = document.createElement("article");
        li.className = "session-card" + (e.sessionId === sid ? " active" : "");
        li.setAttribute("role", "option");
        const main = document.createElement("div");
        main.className = "session-item-main";
        const title = document.createElement("p");
        title.className = "session-name";
        title.textContent = e.title || "未命名会话";
        const sub = document.createElement("p");
        sub.className = "session-meta";
        sub.textContent = e.sessionId.slice(0, 8) + "…";
        main.appendChild(title);
        main.appendChild(sub);
        main.addEventListener("click", () => void api.selectSession(e.sessionId));
        title.addEventListener("dblclick", (ev) => {
          ev.stopPropagation();
          void api.renameSessionPrompt(e.sessionId, e.title || "");
        });
        const act = document.createElement("div");
        act.className = "session-actions";
        const del = document.createElement("button");
        del.type = "button";
        del.className = "btn-icon";
        del.setAttribute("aria-label", "删除会话");
        del.textContent = "×";
        del.addEventListener("click", (ev) => {
          ev.stopPropagation();
          void api.deleteSession(e.sessionId);
        });
        act.appendChild(del);
        li.appendChild(main);
        li.appendChild(act);
        o.el.sessionList.appendChild(li);
      }
    }

    function renderMessagesFromStore() {
      o.el.messages.innerHTML = "";
      const sid = o.getSessionId();
      if (!sid) return;
      for (const m of o.st().getMessages(sid)) {
        const { body } = o.appendMessage(m.role, m.text, {});
        if (m.role === "assistant") o.renderMdBody(body, m.text);
      }
    }

    async function selectSession(id) {
      if (o.getSessionId() && o.getSessionId() !== id) o.persistMsgs();
      o.closeStream();
      if (o.clearTimeline) o.clearTimeline();
      o.setWaitingTaskId(null);
      o.el.waitingPanel.classList.add("hidden");
      o.setSessionId(id);
      o.st().setCurrentSessionId(id);
      renderMessagesFromStore();
      renderSessionList();
      const entry = o.st().loadIndex().find((x) => x.sessionId === id);
      o.el.sessionBanner.textContent = entry
        ? "当前：" + (entry.title || "会话") + " · " + id
        : "当前会话：" + id;
      if (entry && entry.agentId) o.el.agentSelect.value = entry.agentId;
      o.showError("");
      o.setStatus("");
      if (o.renderWorkspace) void o.renderWorkspace();
    }

    async function mergeRemoteSessions() {
      try {
        const remote = await o.fetchJson("/sessions", { method: "GET" });
        for (const s of remote) {
          o.st().upsertEntry({
            sessionId: s.session_id,
            title: s.title || "远程会话",
            updatedAt: Date.parse(s.updated_at || "") || Date.now(),
          });
        }
        renderSessionList();
      } catch {
        /* ignore */
      }
    }

    async function createSession(title) {
      const resolved =
        typeof title === "string" && title.trim() ? title.trim() : defaultSessionTitle();
      const s = await o.fetchJson("/sessions", {
        method: "POST",
        body: JSON.stringify({ title: resolved, trust_level: "verified" }),
      });
      o.st().upsertEntry({
        sessionId: s.session_id,
        title: s.title || resolved,
        agentId: o.el.agentSelect.value || null,
      });
      await selectSession(s.session_id);
    }

    async function deleteSession(id) {
      if (!confirm("删除会话 " + id + " ？")) return;
      try {
        await o.fetchJson("/sessions/" + encodeURIComponent(id) + "/delete", { method: "POST" });
      } catch {
        /* ignore */
      }
      o.st().removeEntry(id);
      const rest = o.st().loadIndex();
      if (id === o.getSessionId()) {
        o.setSessionId(null);
        o.st().setCurrentSessionId("");
        o.el.messages.innerHTML = "";
        o.el.sessionBanner.textContent = "";
        if (rest.length) await selectSession(rest[0].sessionId);
        else await createSession();
      }
      renderSessionList();
    }

    async function renameSessionPrompt(id, currentTitle) {
      const t = prompt("会话标题", currentTitle || "");
      if (t == null) return;
      await o.fetchJson("/sessions/" + encodeURIComponent(id) + "/update", {
        method: "POST",
        body: JSON.stringify({ title: t }),
      });
      o.st().upsertEntry({ sessionId: id, title: t });
      renderSessionList();
      if (id === o.getSessionId()) o.el.sessionBanner.textContent = "当前：" + t + " · " + id;
    }

    async function bootSessions() {
      const legacy = sessionStorage.getItem(o.LEGACY_SESSION);
      if (legacy && o.st().loadIndex().length === 0) {
        try {
          await o.fetchJson("/sessions/" + encodeURIComponent(legacy), { method: "GET" });
          o.st().upsertEntry({ sessionId: legacy, title: "迁移会话" });
        } catch {
          /* ignore */
        }
        sessionStorage.removeItem(o.LEGACY_SESSION);
      }
      await mergeRemoteSessions();
      let cur = o.st().getCurrentSessionId();
      const list = o.st().loadIndex();
      if (!list.length) {
        await createSession();
        return;
      }
      if (!cur || !list.some((x) => x.sessionId === cur)) cur = list[0].sessionId;
      await selectSession(cur);
    }

    const api = {
      renderSessionList,
      renderMessagesFromStore,
      selectSession,
      mergeRemoteSessions,
      createSession,
      deleteSession,
      renameSessionPrompt,
      bootSessions,
    };
    return api;
  };
})(typeof window !== "undefined" ? window : globalThis);
