-- Step 13：支撑 purge_expired 与按过期时间扫描（与 data-retention §Q12 对接；本迁移仅索引）。
-- 部分索引：仅未软删且存在 expires_at 的行。

CREATE INDEX IF NOT EXISTS memory_records_expires_cleanup_idx
    ON memory_records (expires_at)
    WHERE deleted_at IS NULL AND expires_at IS NOT NULL;
