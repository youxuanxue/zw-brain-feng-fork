/**
 * Chat UI helpers：StartTask 请求体（B+C 动态 system prompt、任务模式、metadata）。
 */
(function (w) {
  "use strict";

  const ACTIVE_TASK_STATUSES = ["pending", "running", "waiting_input"];

  function parseDynamicContext(bcDynamicContext) {
    const dcRaw = bcDynamicContext && bcDynamicContext.value && bcDynamicContext.value.trim();
    if (!dcRaw) return { ok: true };
    try {
      return { ok: true, value: JSON.parse(dcRaw) };
    } catch {
      return { ok: false, error: "dynamic_context 必须是合法 JSON。" };
    }
  }

  function parseMetadata(metadataRaw) {
    const metaRaw = metadataRaw && String(metadataRaw).trim();
    if (!metaRaw) return { ok: true };
    try {
      const value = JSON.parse(metaRaw);
      if (!value || Array.isArray(value) || typeof value !== "object") {
        return { ok: false, error: "Task metadata 必须是合法 JSON 对象。" };
      }
      return { ok: true, value: value };
    } catch {
      return { ok: false, error: "Task metadata 必须是合法 JSON 对象。" };
    }
  }

  function applySharedTaskFields(body, bcDynamicContext, bcAppend, opts) {
    const parsedContext = parseDynamicContext(bcDynamicContext);
    if (!parsedContext.ok) return parsedContext;
    if (parsedContext.value !== undefined) body.dynamic_context = parsedContext.value;

    const appendRaw = bcAppend && bcAppend.value && bcAppend.value.trim();
    if (appendRaw) body.system_prompt_append = appendRaw;

    const parsedMetadata = parseMetadata(opts && opts.metadataRaw);
    if (!parsedMetadata.ok) return parsedMetadata;
    if (parsedMetadata.value !== undefined) body.metadata = parsedMetadata.value;

    if (opts && opts.idempotencyKey) body.idempotency_key = String(opts.idempotencyKey);
    if (opts && opts.runKind) body.run_kind = String(opts.runKind);
    if (opts && opts.persistence) body.persistence = String(opts.persistence);
    if (opts && opts.missingContextPolicy) {
      body.missing_context_policy = String(opts.missingContextPolicy);
    }
    return { ok: true, body: body };
  }

  function taskTime(task, fallback) {
    const candidates = [task && task.updated_at, task && task.started_at, task && task.created_at, task && task.finished_at];
    for (const value of candidates) {
      const parsed = Date.parse(value || "");
      if (Number.isFinite(parsed)) return parsed;
    }
    return fallback;
  }

  function errorType(err) {
    const payload = err && err.payload;
    if (payload && payload.error && payload.error.type) return payload.error.type;
    if (payload && payload.type) return payload.type;
    return err && err.type;
  }

  function busyError(active) {
    const err = new Error("当前会话仍有任务运行中，请等待完成、取消或进入等待输入后再发送。");
    err.status = 409;
    err.type = "session_busy";
    err.activeTask = active || null;
    return err;
  }

  w.findActiveSessionTask = function (sessionState) {
    const tasks = Array.isArray(sessionState && sessionState.tasks) ? sessionState.tasks : [];
    const active = tasks
      .map((task, index) => ({ task: task, index: index, time: taskTime(task, index) }))
      .filter((item) => item.task && ACTIVE_TASK_STATUSES.includes(item.task.status));
    if (!active.length) return null;
    active.sort((a, b) => (a.time === b.time ? a.index - b.index : a.time - b.time));
    const waiting = active.filter((item) => item.task.status === "waiting_input");
    if (waiting.length) return waiting[waiting.length - 1].task;
    return active[active.length - 1].task;
  };

  w.buildStartTaskBody = function (sessionId, agentId, inputText, bcDynamicContext, bcAppend, opts) {
    opts = opts || {};
    const body = {
      session_id: sessionId,
      agent_id: agentId,
      input: inputText,
    };
    if (opts.workspaceId) body.workspace_id = opts.workspaceId;
    if (Array.isArray(opts.files) && opts.files.length) body.files = opts.files;
    const shared = applySharedTaskFields(body, bcDynamicContext, bcAppend, opts);
    if (!shared.ok) return { ok: false, error: shared.error };
    return { ok: true, body: body };
  };

  w.buildResumeTaskBody = function (inputText, bcDynamicContext, bcAppend, opts) {
    opts = opts || {};
    const body = { input: inputText };
    const shared = applySharedTaskFields(body, bcDynamicContext, bcAppend, opts);
    if (!shared.ok) return { ok: false, error: shared.error };
    if (opts.actor) body.actor = opts.actor;
    return { ok: true, body: body };
  };

  async function resumeChatTask(fetchJson, task, inputText, bcDynamicContext, bcAppend, opts) {
    const built = w.buildResumeTaskBody(inputText, bcDynamicContext, bcAppend, opts);
    if (!built.ok) return { ok: false, error: built.error };
    const taskId = task && task.task_id;
    if (!taskId) return { ok: false, error: "无法恢复任务：缺少 task_id。" };
    const resumed = await fetchJson("/tasks/" + encodeURIComponent(taskId) + "/resume", {
      method: "POST",
      body: JSON.stringify(built.body),
    });
    return { ok: true, action: "resume", task: resumed || task, taskId: taskId };
  }

  w.sendChatMessage = async function (opts) {
    opts = opts || {};
    const fetchJson = opts.fetchJson;
    if (typeof fetchJson !== "function") throw new Error("sendChatMessage requires fetchJson.");
    const sessionId = opts.sessionId;
    const agentId = opts.agentId;
    const inputText = opts.input;
    if (!sessionId) return { ok: false, error: "请先选择或创建会话。" };
    if (!agentId) return { ok: false, error: "请选择 Agent。" };
    if (!String(inputText || "").trim()) return { ok: false, error: "请输入消息。" };

    const state = await fetchJson("/sessions/" + encodeURIComponent(sessionId) + "/state", { method: "GET" });
    const active = w.findActiveSessionTask(state);
    if (active && active.status === "waiting_input") {
      return resumeChatTask(fetchJson, active, inputText, opts.bcDynamicContext, opts.bcAppend, opts);
    }
    if (active) throw busyError(active);

    const built = w.buildStartTaskBody(sessionId, agentId, inputText, opts.bcDynamicContext, opts.bcAppend, opts);
    if (!built.ok) return { ok: false, error: built.error };
    try {
      const task = await fetchJson("/tasks", { method: "POST", body: JSON.stringify(built.body) });
      return { ok: true, action: "start", task: task, taskId: task && task.task_id };
    } catch (err) {
      if (err && err.status === 409 && errorType(err) === "session_busy") {
        const refreshed = await fetchJson("/sessions/" + encodeURIComponent(sessionId) + "/state", { method: "GET" });
        const refreshedActive = w.findActiveSessionTask(refreshed);
        if (refreshedActive && refreshedActive.status === "waiting_input") {
          return resumeChatTask(fetchJson, refreshedActive, inputText, opts.bcDynamicContext, opts.bcAppend, opts);
        }
        if (refreshedActive) throw busyError(refreshedActive);
      }
      throw err;
    }
  };

  w.maybePresetContextEchoAgent = function (agentId, bcDynamicContext, bcPanel) {
    if (
      agentId === "context-echo-dynamic-prompt-agent" &&
      bcDynamicContext &&
      !bcDynamicContext.value.trim()
    ) {
      bcDynamicContext.value = '{"user_display_name":"网页用户","task_topic":"Chat 联调"}';
      if (bcPanel && !bcPanel.open) bcPanel.open = true;
    }
  };
})(typeof window !== "undefined" ? window : globalThis);
