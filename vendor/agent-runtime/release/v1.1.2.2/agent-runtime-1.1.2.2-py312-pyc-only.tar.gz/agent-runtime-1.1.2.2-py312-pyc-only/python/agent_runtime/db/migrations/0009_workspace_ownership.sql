CREATE TABLE IF NOT EXISTS workspace_ownership (
    workspace_id TEXT PRIMARY KEY,
    tenant_id TEXT,
    owner_user_id TEXT,
    owner_principal_id TEXT,
    session_id UUID,
    task_id UUID,
    source TEXT NOT NULL,
    isolation TEXT NOT NULL,
    retention TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_workspace_ownership_owner_user
    ON workspace_ownership (owner_user_id);

CREATE INDEX IF NOT EXISTS idx_workspace_ownership_owner_principal
    ON workspace_ownership (owner_principal_id);

CREATE INDEX IF NOT EXISTS idx_workspace_ownership_tenant
    ON workspace_ownership (tenant_id);

CREATE INDEX IF NOT EXISTS idx_workspace_ownership_session
    ON workspace_ownership (session_id);

CREATE INDEX IF NOT EXISTS idx_workspace_ownership_task
    ON workspace_ownership (task_id);
