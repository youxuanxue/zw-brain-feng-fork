ALTER TABLE task_events
    ADD COLUMN IF NOT EXISTS correlation_id TEXT,
    ADD COLUMN IF NOT EXISTS audit_event_id TEXT;

CREATE INDEX IF NOT EXISTS task_events_correlation_id_idx
    ON task_events(correlation_id);
