-- MemoryBackend 一等存储（spec §10、data-retention §Q12）；不含向量/检索实现。
CREATE TABLE IF NOT EXISTS memory_records (
    memory_id TEXT PRIMARY KEY,
    namespace TEXT NOT NULL,
    user_id TEXT,
    session_id UUID REFERENCES sessions(session_id) ON DELETE SET NULL,
    agent_id TEXT,
    content JSONB NOT NULL DEFAULT '{}'::jsonb,
    source_refs JSONB,
    deleted_at TIMESTAMPTZ,
    expires_at TIMESTAMPTZ,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS memory_records_namespace_user_idx
    ON memory_records(namespace, user_id) WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS memory_records_session_idx
    ON memory_records(session_id) WHERE deleted_at IS NULL;
