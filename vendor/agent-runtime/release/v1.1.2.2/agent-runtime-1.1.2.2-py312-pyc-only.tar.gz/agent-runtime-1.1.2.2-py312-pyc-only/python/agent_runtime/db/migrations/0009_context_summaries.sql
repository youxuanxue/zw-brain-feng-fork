-- Context governance: persisted session-level summaries (spec §4.6–8), not MessageStore rows.
CREATE TABLE IF NOT EXISTS context_summaries (
    summary_id TEXT PRIMARY KEY,
    session_id UUID NOT NULL REFERENCES sessions(session_id) ON DELETE CASCADE,
    scope TEXT NOT NULL,
    summary_text TEXT NOT NULL,
    checksum TEXT NOT NULL,
    hierarchy_level INT NOT NULL DEFAULT 0,
    message_range JSONB,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS context_summaries_session_scope_created_idx
    ON context_summaries(session_id, scope, created_at DESC);
