-- Spec 2026-05-06 §10 — Resource ownership for sessions/tasks; idempotency hash projection.

ALTER TABLE sessions
    ADD COLUMN IF NOT EXISTS owner_user_id TEXT,
    ADD COLUMN IF NOT EXISTS owner_principal_id TEXT,
    ADD COLUMN IF NOT EXISTS tenant_id TEXT,
    ADD COLUMN IF NOT EXISTS created_by_principal_id TEXT,
    ADD COLUMN IF NOT EXISTS created_by_auth_method TEXT;

CREATE INDEX IF NOT EXISTS sessions_owner_user_idx
    ON sessions(owner_user_id);
CREATE INDEX IF NOT EXISTS sessions_owner_principal_idx
    ON sessions(owner_principal_id);

ALTER TABLE tasks
    ADD COLUMN IF NOT EXISTS owner_user_id TEXT,
    ADD COLUMN IF NOT EXISTS owner_principal_id TEXT,
    ADD COLUMN IF NOT EXISTS actor_principal_id TEXT,
    ADD COLUMN IF NOT EXISTS subject_user_id TEXT,
    ADD COLUMN IF NOT EXISTS request_hash TEXT;

CREATE INDEX IF NOT EXISTS tasks_owner_user_idx
    ON tasks(owner_user_id);
CREATE INDEX IF NOT EXISTS tasks_owner_principal_idx
    ON tasks(owner_principal_id);
