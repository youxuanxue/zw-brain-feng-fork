(function () {
  "use strict";

  const LEGACY_SESSION = "agent_runtime_chat_session_id";
  const MAX_UPLOAD_FILES = 20;
  const MAX_UPLOAD_FILE_BYTES = 25 * 1024 * 1024;
  const apiBase = () => window.location.origin;
  const st = () => window.chatStorage;

  const el = {
    agentSelect: document.getElementById("agent-select"),
    agentError: document.getElementById("agent-error"),
    artifactRequirement: document.getElementById("artifact-requirement"),
    btnRefreshSessions: document.getElementById("btn-refresh-sessions"),
    btnNewSession: document.getElementById("btn-new-session"),
    btnCopySession: document.getElementById("btn-copy-session"),
    btnCopyWorkspace: document.getElementById("btn-copy-workspace"),
    sessionList: document.getElementById("session-list"),
    activeTitle: document.getElementById("active-title"),
    activeSubtitle: document.getElementById("active-subtitle"),
    statusCard: document.getElementById("status-card"),
    statusText: document.getElementById("status-text"),
    liveDot: document.getElementById("rail-live-dot"),
    runConsole: document.querySelector(".run-console"),
    taskInput: document.getElementById("task-input"),
    taskInputError: document.getElementById("task-input-error"),
    taskFiles: document.getElementById("task-files"),
    selectedFiles: document.getElementById("selected-files"),
    taskFilesError: document.getElementById("task-files-error"),
    taskMetadata: document.getElementById("task-metadata"),
    metadataError: document.getElementById("metadata-error"),
    dynamicContext: document.getElementById("dynamic-context"),
    dynamicContextError: document.getElementById("dynamic-context-error"),
    promptAppend: document.getElementById("prompt-append"),
    btnCancel: document.getElementById("btn-cancel"),
    btnSend: document.getElementById("btn-send"),
    errorStack: document.getElementById("error-stack"),
    waitingPanel: document.getElementById("waiting-panel"),
    waitingTitle: document.getElementById("waiting-title"),
    waitingKind: document.getElementById("waiting-kind"),
    waitingSource: document.getElementById("waiting-source"),
    waitingAgentNote: document.getElementById("waiting-agent-note"),
    waitingAgentText: document.getElementById("waiting-agent-text"),
    waitingSuggestion: document.getElementById("waiting-suggestion"),
    waitingPayload: document.getElementById("waiting-payload"),
    waitingInput: document.getElementById("waiting-input"),
    waitingError: document.getElementById("waiting-error"),
    btnResume: document.getElementById("btn-resume"),
    messages: document.getElementById("messages"),
    btnRetry: document.getElementById("btn-retry"),
    btnLoadSessionState: document.getElementById("btn-load-session-state"),
    btnCopyTask: document.getElementById("btn-copy-task"),
    btnCopyTrace: document.getElementById("btn-copy-trace"),
    eventCount: document.getElementById("event-count"),
    failureCount: document.getElementById("failure-count"),
    requestJson: document.getElementById("request-json"),
    btnCopyRequest: document.getElementById("btn-copy-request"),
    eventList: document.getElementById("event-list"),
    btnLoadEvents: document.getElementById("btn-load-events"),
    btnRefreshWorkspace: document.getElementById("btn-refresh-workspace"),
    workspaceList: document.getElementById("workspace-list"),
    rawJson: document.getElementById("raw-json"),
    btnCopyRaw: document.getElementById("btn-copy-raw"),
  };

  const state = {
    sessionId: null,
    activeTaskId: null,
    waitingTaskId: null,
    currentTraceId: "",
    currentError: null,
    pendingAskUserPrompt: "",
    waitingPayload: null,
    waitingAgentText: "",
    waitingSequence: null,
    eventSource: null,
    events: [],
    failures: 0,
    activeAssistantWrap: null,
    runGroups: new Map(),
    lastRequestBody: null,
    lastInput: "",
    selectedFiles: [],
    workspaceTree: {
      workspaceId: "",
      expanded: new Set(),
      children: new Map(),
      loading: new Set(),
      errors: new Map(),
    },
    isBusy: false,
  };

  function text(value) {
    return value == null ? "" : String(value);
  }

  function shortId(value) {
    const s = text(value);
    if (!s) return "none";
    return s.length > 14 ? s.slice(0, 8) + "…" + s.slice(-4) : s;
  }

  function asJson(value) {
    try {
      return JSON.stringify(value, null, 2);
    } catch {
      return text(value);
    }
  }

  function parseMaybeJson(value) {
    if (!value || typeof value !== "string") return value;
    try {
      return JSON.parse(value);
    } catch {
      return value;
    }
  }

  function readEventData(ev) {
    try {
      return JSON.parse(ev.data);
    } catch {
      return { payload: { raw: ev.data } };
    }
  }

  function isPlainObject(value) {
    return value != null && typeof value === "object" && !Array.isArray(value);
  }

  function copyText(value, label) {
    const body = text(value);
    if (!body) return;
    navigator.clipboard.writeText(body).then(
      () => setStatus("copied", label + " 已复制"),
      () => setStatus("failed", "复制失败")
    );
  }

  function selectedAgentLabel() {
    const opt = el.agentSelect.options[el.agentSelect.selectedIndex];
    return opt && opt.textContent ? opt.textContent : "未选择 Agent";
  }

  function selectedAgentName() {
    const raw = selectedAgentLabel();
    const idx = raw.lastIndexOf(" (");
    return idx > 0 && raw.endsWith(")") ? raw.slice(0, idx) : raw;
  }

  function selectedAgentTrustLevel() {
    const opt = el.agentSelect.options[el.agentSelect.selectedIndex];
    return (opt && opt.dataset && opt.dataset.trustLevel) || "verified";
  }

  function workspaceId() {
    return state.sessionId ? "session-" + state.sessionId : "";
  }

  function setStatus(kind, message) {
    el.statusCard.dataset.state = kind || "idle";
    const label = el.statusCard.querySelector(".status-label");
    if (label) label.textContent = kind || "idle";
    el.statusText.textContent = message || "准备就绪";
    el.liveDot.classList.toggle("active", ["posting", "streaming", "waiting", "resuming"].includes(kind));
  }

  function setBusy(isBusy) {
    state.isBusy = isBusy;
    el.btnSend.disabled = isBusy;
    el.taskInput.disabled = isBusy;
    el.btnCancel.disabled = !isBusy || !state.activeTaskId;
    el.agentSelect.disabled = isBusy;
    if (el.taskMode) el.taskMode.disabled = isBusy;
    el.artifactRequirement.disabled = isBusy;
    el.taskMetadata.disabled = isBusy;
    el.dynamicContext.disabled = isBusy;
    el.promptAppend.disabled = isBusy;
    if (el.taskFiles) el.taskFiles.disabled = false;
  }

  function clearFieldError(node) {
    if (!node) return;
    node.hidden = true;
    node.textContent = "";
  }

  function setFieldError(node, message) {
    if (!node) return;
    node.hidden = false;
    node.textContent = message;
  }

  function clearValidationErrors() {
    clearFieldError(el.agentError);
    clearFieldError(el.taskInputError);
    clearFieldError(el.metadataError);
    clearFieldError(el.dynamicContextError);
    clearFieldError(el.waitingError);
    clearFieldError(el.taskFilesError);
  }

  function normalizeError(error, fallback) {
    if (!error) return { message: fallback || "未知错误" };
    if (error.runtimeError) return error.runtimeError;
    if (error.error && typeof error.error === "object") return error.error;
    if (typeof error === "object") {
      return {
        type: error.type || error.name || "Error",
        message: error.message || fallback || asJson(error),
        retryable: error.retryable,
        task_id: error.task_id,
        trace_id: error.trace_id,
        details: error.details || error.detail,
      };
    }
    return { message: text(error) || fallback || "未知错误" };
  }

  function setRawDetail(value) {
    const raw = typeof value === "string" ? value : asJson(value);
    el.rawJson.textContent = raw || "无详情。";
    el.btnCopyRaw.disabled = !raw;
  }

  function formatBytes(value) {
    const size = Number(value) || 0;
    if (size < 1024) return String(size) + " B";
    if (size < 1024 * 1024) return (size / 1024).toFixed(1) + " KB";
    return (size / (1024 * 1024)).toFixed(1) + " MB";
  }

  function validateSelectedFiles(files) {
    if (files.length > MAX_UPLOAD_FILES) return "一次最多上传 " + MAX_UPLOAD_FILES + " 个文件。";
    const invalidName = files.find((file) => !text(file && file.name).trim());
    if (invalidName) return "存在缺少文件名的附件。";
    const oversized = files.find((file) => file.size > MAX_UPLOAD_FILE_BYTES);
    if (oversized) return "附件 " + oversized.name + " 超过 " + formatBytes(MAX_UPLOAD_FILE_BYTES) + "。";
    return "";
  }

  function setUploadSummary(message, tone) {
    if (!el.selectedFiles) return;
    el.selectedFiles.textContent = message || "上传到 workspace uploads/";
    el.selectedFiles.dataset.tone = tone || "idle";
  }

  function clearSelectedFiles(options) {
    if (el.taskFiles) el.taskFiles.value = "";
    state.selectedFiles = [];
    clearFieldError(el.taskFilesError);
    if (!options || !options.keepSummary) setUploadSummary("上传到 workspace uploads/", "idle");
  }

  function handleFileSelection() {
    const files = Array.from((el.taskFiles && el.taskFiles.files) || []);
    state.selectedFiles = files;
    void uploadSelectedFilesToWorkspace();
  }

  function readFileAsBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error("无法读取文件：" + file.name));
      reader.onload = () => {
        const result = String(reader.result || "");
        const comma = result.indexOf(",");
        resolve(comma >= 0 ? result.slice(comma + 1) : result);
      };
      reader.readAsDataURL(file);
    });
  }

  async function uploadSelectedFilesToWorkspace() {
    if (!state.selectedFiles.length) return;
    if (!state.sessionId) {
      setFieldError(el.taskFilesError, "请先创建或选择一个 session，再上传附件到 workspace。");
      setUploadSummary("等待 session", "error");
      return;
    }
    const validationError = validateSelectedFiles(state.selectedFiles);
    if (validationError) {
      if (el.taskFiles) el.taskFiles.value = "";
      setFieldError(el.taskFilesError, validationError);
      setUploadSummary("上传失败", "error");
      state.selectedFiles = [];
      return;
    }
    clearFieldError(el.taskFilesError);
    setUploadSummary("上传中 " + state.selectedFiles.length + " 个文件…", "busy");
    try {
      const uploaded = [];
      for (const file of state.selectedFiles) {
        const content = await readFileAsBase64(file);
        const path = "uploads/" + file.name;
        await fetchJson("/workspaces/" + encodeURIComponent(workspaceId()) + "/files/content?path=" + encodeURIComponent(path), {
          method: "POST",
          body: JSON.stringify({ content: content, encoding: "base64" }),
        });
        uploaded.push(path);
      }
      clearSelectedFiles({ keepSummary: true });
      setUploadSummary("已上传 " + uploaded.length + " 个文件", "success");
      await renderWorkspace();
      setRawDetail({ workspace_upload: { workspace_id: workspaceId(), paths: uploaded } });
      setStatus("uploaded", "附件已上传到 workspace");
    } catch (error) {
      const normalized = normalizeError(error, "上传附件失败。");
      setFieldError(el.taskFilesError, normalized.message || "上传附件失败。");
      setRawDetail({ workspace_upload_error: normalized });
      setUploadSummary("上传失败", "error");
    }
  }

  function redactRequestForDisplay(body) {
    if (!body || !Array.isArray(body.files) || !body.files.length) return body;
    return {
      ...body,
      files: body.files.map((file) => ({
        ...file,
        content_base64: file.content_base64 ? "[base64 " + file.content_base64.length + " chars]" : "",
      })),
    };
  }

  function updateInspector() {
    el.btnCopyTask.textContent = shortId(state.activeTaskId);
    el.btnCopyTask.disabled = !state.activeTaskId;
    el.btnCopyTrace.textContent = shortId(state.currentTraceId);
    el.btnCopyTrace.disabled = !state.currentTraceId;
    el.eventCount.textContent = String(state.events.length);
    el.failureCount.textContent = String(state.failures);
    el.btnLoadEvents.disabled = !state.activeTaskId;
    el.btnRefreshWorkspace.disabled = !state.sessionId;
    el.btnLoadSessionState.disabled = !state.sessionId;
    el.btnCopyRequest.disabled = !state.lastRequestBody;
    el.requestJson.textContent = state.lastRequestBody ? asJson(state.lastRequestBody) : "等待构造请求体。";
  }

  function workspaceEmpty(message) {
    const row = document.createElement("div");
    row.className = "workspace-empty";
    row.textContent = message;
    return row;
  }

  function renderWorkspaceContext(workspaceIdValue) {
    const row = document.createElement("div");
    row.className = "workspace-file workspace-context";
    const name = document.createElement("span");
    name.textContent = "workspace_id";
    const detail = document.createElement("code");
    detail.textContent = workspaceIdValue || "未绑定";
    row.append(name, detail);
    el.workspaceList.appendChild(row);
  }

  function resetWorkspaceTree(wid, keepExpanded) {
    const previousExpanded = state.workspaceTree && state.workspaceTree.workspaceId === wid ? state.workspaceTree.expanded : new Set();
    state.workspaceTree = {
      workspaceId: wid,
      expanded: keepExpanded ? new Set(previousExpanded) : new Set(),
      children: new Map(),
      loading: new Set(),
      errors: new Map(),
    };
  }

  function workspacePathName(path) {
    const parts = text(path).split("/").filter(Boolean);
    return parts.length ? parts[parts.length - 1] : path || "/";
  }

  function workspaceChildrenId(path) {
    const safe = text(path || "root").replace(/[^a-zA-Z0-9_-]+/g, "-");
    return "workspace-children-" + safe;
  }

  function workspaceDownloadUrl(path) {
    return apiBase() + "/workspaces/" + encodeURIComponent(workspaceId()) + "/files/content?path=" + encodeURIComponent(path) + "&download=true";
  }

  async function loadWorkspacePath(path) {
    const normalizedPath = text(path);
    const tree = state.workspaceTree;
    if (!state.sessionId || !tree.workspaceId) return [];
    if (tree.loading.has(normalizedPath)) return tree.children.get(normalizedPath) || [];
    tree.loading.add(normalizedPath);
    tree.errors.delete(normalizedPath);
    renderWorkspaceTree();
    try {
      const payload = await fetchJson(
        "/workspaces/" + encodeURIComponent(tree.workspaceId) + "/files?path=" + encodeURIComponent(normalizedPath),
        { method: "GET" }
      );
      const entries = ((payload && payload.entries) || []).slice().sort((a, b) => {
        if (Boolean(a.is_dir) !== Boolean(b.is_dir)) return a.is_dir ? -1 : 1;
        return workspacePathName(a.path).localeCompare(workspacePathName(b.path), "zh-CN");
      });
      tree.children.set(normalizedPath, entries);
      return entries;
    } catch (error) {
      tree.errors.set(normalizedPath, normalizeError(error).message || "无法加载目录。");
      return [];
    } finally {
      tree.loading.delete(normalizedPath);
      renderWorkspaceTree();
    }
  }

  function renderWorkspaceTree() {
    if (!el.workspaceList) return;
    el.workspaceList.innerHTML = "";
    if (!state.sessionId) {
      el.workspaceList.appendChild(workspaceEmpty("选择或创建会话后显示工作区内容。"));
      return;
    }
    const wid = workspaceId();
    renderWorkspaceContext(wid);
    const tree = state.workspaceTree;
    const rootEntries = tree.children.get("") || [];
    const rootError = tree.errors.get("");
    if (tree.loading.has("") && !rootEntries.length) {
      el.workspaceList.appendChild(workspaceEmpty("正在加载工作区文件…"));
      return;
    }
    if (rootError && !rootEntries.length) {
      el.workspaceList.appendChild(workspaceEmpty("无法加载工作区文件：" + rootError));
      return;
    }
    if (!rootEntries.length) {
      el.workspaceList.appendChild(workspaceEmpty("工作区暂无文件。Agent 写入后会自动出现。"));
      return;
    }
    const treeWrap = document.createElement("div");
    treeWrap.className = "workspace-tree";
    treeWrap.setAttribute("role", "tree");
    rootEntries.forEach((entry) => appendWorkspaceEntry(treeWrap, entry, 0));
    el.workspaceList.appendChild(treeWrap);
  }

  function appendWorkspaceEntry(container, entry, depth) {
    const path = text(entry && entry.path);
    const isDir = Boolean(entry && entry.is_dir);
    const row = document.createElement("div");
    row.className = "workspace-file workspace-tree-row" + (isDir ? " is-dir" : " is-file");
    row.style.setProperty("--depth", String(depth));
    row.setAttribute("role", "treeitem");
    if (isDir) {
      const expanded = state.workspaceTree.expanded.has(path);
      row.setAttribute("aria-expanded", expanded ? "true" : "false");
      row.setAttribute("aria-controls", workspaceChildrenId(path));
      row.tabIndex = 0;
      row.addEventListener("click", () => void toggleWorkspaceDirectory(path));
      row.addEventListener("keydown", (ev) => {
        if (ev.key === "Enter" || ev.key === " ") {
          ev.preventDefault();
          void toggleWorkspaceDirectory(path);
        }
      });
    }

    const name = document.createElement("span");
    name.className = "workspace-file-name";
    const twisty = document.createElement("span");
    twisty.className = "workspace-twisty";
    twisty.setAttribute("aria-hidden", "true");
    twisty.textContent = isDir ? (state.workspaceTree.expanded.has(path) ? "▾" : "▸") : "";
    const label = document.createElement("span");
    label.className = "workspace-file-label";
    label.textContent = workspacePathName(path);
    name.append(twisty, label);

    const actions = document.createElement("span");
    actions.className = "workspace-file-actions";
    const detail = document.createElement("code");
    detail.textContent = isDir ? (state.workspaceTree.loading.has(path) ? "loading" : "dir") : formatBytes(entry.size);
    actions.appendChild(detail);
    if (!isDir) {
      const link = document.createElement("a");
      link.className = "workspace-download cursor-pointer";
      link.href = workspaceDownloadUrl(path);
      link.download = workspacePathName(path);
      link.textContent = "下载";
      link.setAttribute("aria-label", "下载 " + path);
      link.addEventListener("click", (ev) => ev.stopPropagation());
      actions.appendChild(link);
    }
    row.append(name, actions);
    container.appendChild(row);

    if (!isDir || !state.workspaceTree.expanded.has(path)) return;
    const childrenWrap = document.createElement("div");
    childrenWrap.className = "workspace-tree-children";
    childrenWrap.id = workspaceChildrenId(path);
    childrenWrap.setAttribute("role", "group");
    const error = state.workspaceTree.errors.get(path);
    const children = state.workspaceTree.children.get(path) || [];
    if (state.workspaceTree.loading.has(path) && !children.length) {
      childrenWrap.appendChild(workspaceEmpty("正在加载目录…"));
    } else if (error && !children.length) {
      childrenWrap.appendChild(workspaceEmpty("无法加载目录：" + error));
    } else if (!children.length) {
      childrenWrap.appendChild(workspaceEmpty("空目录。"));
    } else {
      children.forEach((child) => appendWorkspaceEntry(childrenWrap, child, depth + 1));
    }
    container.appendChild(childrenWrap);
  }

  async function toggleWorkspaceDirectory(path) {
    const tree = state.workspaceTree;
    if (tree.expanded.has(path)) {
      tree.expanded.delete(path);
      renderWorkspaceTree();
      return;
    }
    tree.expanded.add(path);
    if (!tree.children.has(path) && !tree.loading.has(path)) {
      await loadWorkspacePath(path);
      return;
    }
    renderWorkspaceTree();
  }

  async function renderWorkspace(options) {
    if (!el.workspaceList) return;
    options = options || {};
    if (!state.sessionId) {
      resetWorkspaceTree("", false);
      renderWorkspaceTree();
      return;
    }
    const wid = workspaceId();
    const preserveExpanded = options.preserveExpanded !== false;
    if (state.workspaceTree.workspaceId !== wid || options.forceReload || !state.workspaceTree.children.has("")) {
      resetWorkspaceTree(wid, preserveExpanded);
    }
    const expandedPaths = Array.from(state.workspaceTree.expanded);
    await loadWorkspacePath("");
    for (const path of expandedPaths) {
      if (state.workspaceTree.expanded.has(path)) await loadWorkspacePath(path);
    }
  }

  function updateIdentity() {
    const sid = state.sessionId;
    const wid = workspaceId();
    el.btnCopySession.textContent = sid ? shortId(sid) : "未创建";
    el.btnCopySession.disabled = !sid;
    el.btnCopyWorkspace.textContent = wid ? shortId(wid) : "未绑定";
    el.btnCopyWorkspace.disabled = !wid;
    el.activeTitle.textContent = sid ? selectedAgentName() + " 测试会话" : "选择 agent 后发送测试任务";
    el.activeSubtitle.textContent = sid
      ? "agent " + (el.agentSelect.value || "未选择") + " · workspace " + wid + artifactSummarySuffix()
      : "错误、事件、tool calls 和原始请求会分层显示。";
    updateInspector();
  }

  function artifactSummarySuffix() {
    const kind = el.artifactRequirement && el.artifactRequirement.value;
    return kind && kind !== "none" ? " · requires *." + kind : "";
  }

  async function fetchJson(path, options) {
    const res = await fetch(apiBase() + path, {
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      ...options,
    });
    const ct = res.headers.get("content-type") || "";
    const body = ct.includes("application/json") ? await res.json() : await res.text();
    if (!res.ok) {
      const error = new Error("HTTP " + res.status);
      const runtimeError = body && typeof body === "object" && body.error ? body.error : null;
      error.runtimeError = runtimeError || {
        type: body && body.detail ? "HTTP_" + res.status : "HTTP_ERROR",
        message: runtimeError ? runtimeError.message : body && body.detail ? text(body.detail) : text(body || res.statusText),
        retryable: res.status >= 500,
        details: body,
      };
      throw error;
    }
    return body;
  }

  function emptyMessages() {
    el.messages.innerHTML = "";
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.classList.add("conversation-empty");
    empty.innerHTML = "<span>START A RUN</span><p>描述你希望 Agent 完成的工作。运行后，这里会保留用户输入、assistant 输出和等待确认。</p>";
    el.messages.appendChild(empty);
  }

  function ensureMessagesReady() {
    const empty = el.messages.querySelector(".empty-state");
    if (empty) empty.remove();
  }

  function appendMessage(role, message, opts) {
    ensureMessagesReady();
    const card = document.createElement("article");
    card.className = "message-card " + role;
    if (opts && opts.streaming) card.classList.add("streaming", "msg-streaming");
    if (opts && opts.error) card.classList.add("error");

    const head = document.createElement("div");
    head.className = "message-head";
    const roleEl = document.createElement("span");
    roleEl.className = "message-role";
    roleEl.textContent = role === "user" ? "You" : role === "assistant" ? selectedAgentName() : "Runtime";
    const time = document.createElement("span");
    time.className = "event-meta";
    time.textContent = new Date().toLocaleTimeString("zh-CN", { hour12: false });
    head.append(roleEl, time);

    const body = document.createElement("div");
    body.className = "message-body";
    body.textContent = message || "";
    card.append(head, body);
    el.messages.appendChild(card);
    scrollMessages();
    return { wrap: card, body };
  }

  function appendToolLine(wrap, line) {
    const node = document.createElement("div");
    node.className = "tool-line";
    node.textContent = line;
    wrap.appendChild(node);
    scrollMessages();
  }

  function taskIdFromRow(row) {
    const raw = (row && row.raw) || {};
    return raw.task_id || raw.taskId || row.taskId || state.activeTaskId || state.waitingTaskId || "session";
  }

  function rowSequence(row) {
    const raw = (row && row.raw) || {};
    return raw.sequence || row.sequence || "";
  }

  function eventDomId(row) {
    return "run-event-" + eventDedupeKey(row).replace(/[^a-zA-Z0-9_-]+/g, "-");
  }

  function ensureRunGroup(taskId, assistantWrap) {
    const key = text(taskId || state.activeTaskId || state.waitingTaskId || "session");
    let group = state.runGroups.get(key);
    const wrap = assistantWrap || (group && group.wrap) || state.activeAssistantWrap || el.messages.querySelector(".message-card.assistant:last-of-type");
    if (!wrap) return null;
    if (!group) {
      wrap.classList.add("run-message");
      const container = document.createElement("section");
      container.className = "run-events";
      container.setAttribute("aria-label", "运行过程");
      const summary = document.createElement("button");
      summary.type = "button";
      summary.className = "run-summary cursor-pointer";
      summary.setAttribute("aria-expanded", "true");
      const summaryText = document.createElement("span");
      summaryText.className = "run-summary-text";
      summaryText.textContent = "运行过程 · 0 events";
      const summaryState = document.createElement("span");
      summaryState.className = "run-summary-state";
      summaryState.textContent = "live";
      summary.append(summaryText, summaryState);
      const list = document.createElement("div");
      list.className = "run-event-list";
      summary.addEventListener("click", () => {
        const collapsed = container.classList.toggle("collapsed");
        summary.setAttribute("aria-expanded", collapsed ? "false" : "true");
      });
      container.append(summary, list);
      wrap.appendChild(container);
      group = { taskId: key, wrap, container, summaryText, summaryState, list, count: 0, status: "live", itemKeys: new Set() };
      state.runGroups.set(key, group);
    }
    return group;
  }

  function truncateText(value, limit) {
    const body = text(value).replace(/\s+/g, " ").trim();
    if (!body) return "";
    const max = limit || 180;
    return body.length > max ? body.slice(0, max - 1) + "…" : body;
  }

  function pickText(source, keys) {
    if (!source || typeof source !== "object") return "";
    for (const key of keys) {
      const value = source[key];
      if (typeof value === "string" && value.trim()) return value.trim();
    }
    return "";
  }

  function summarizeObject(value, fallback) {
    if (value == null || value === "") return fallback || "";
    if (typeof value === "string") return truncateText(value);
    if (Array.isArray(value)) {
      const textItems = value.map((item) => (typeof item === "string" ? item : pickText(item, ["path", "name", "tool_name", "message", "type"]))).filter(Boolean);
      return textItems.length ? truncateText(textItems.slice(0, 3).join("、") + (textItems.length > 3 ? " 等 " + textItems.length + " 项" : "")) : (fallback || "包含 " + value.length + " 项结果");
    }
    if (typeof value === "object") {
      const direct = pickText(value, ["message", "display_message", "summary", "reason", "status", "path", "name", "tool_name", "type"]);
      if (direct) return truncateText(direct);
      const keys = Object.keys(value).filter((key) => value[key] != null).slice(0, 5);
      return fallback || (keys.length ? "包含字段：" + keys.join("、") : "详情已记录");
    }
    return truncateText(value);
  }

  function compactPayloadValue(value) {
    return summarizeObject(value, "详情已记录，点击查看完整 payload。");
  }

  function formatBytes(value) {
    const size = Number(value);
    if (!Number.isFinite(size) || size < 0) return "";
    if (size < 1024) return size + " B";
    if (size < 1024 * 1024) return (size / 1024).toFixed(1).replace(/\.0$/, "") + " KB";
    return (size / 1024 / 1024).toFixed(1).replace(/\.0$/, "") + " MB";
  }

  function toolNameFromPayload(payload) {
    const p = payload || {};
    return text(p.tool_name || p.name || p.tool || p.function_name || p.function || "tool");
  }

  function pathFromPayload(payload) {
    const p = payload || {};
    const args = p.args_preview || p.args || p.input || p.result || p.output || {};
    return text(p.path || p.file || p.workspace_path || p.target_path || p.output_path || args.path || args.file || args.workspace_path || args.target_path || args.output_path || "");
  }

  function errorTextFromPayload(payload) {
    const p = payload || {};
    const err = p.error || p.details || {};
    return pickText(err, ["message", "type", "error", "reason"]) || pickText(p, ["message", "error", "reason", "display_message"]) || summarizeObject(p, "发生错误，点击查看详情。");
  }

  function toolDetail(payload, phase) {
    const path = pathFromPayload(payload);
    if (path) return (phase === "completed" ? "已处理 " : phase === "failed" ? "处理失败 " : "正在处理 ") + path;
    const p = payload || {};
    const args = p.args_preview || p.args || p.input;
    const result = p.result || p.output;
    if (phase === "started") return summarizeObject(args, "正在执行工具调用…");
    if (phase === "completed") return summarizeObject(result, "工具调用已完成。");
    return errorTextFromPayload(p);
  }

  function workspaceDetail(payload) {
    const p = payload || {};
    const path = pathFromPayload(p) || pickText(p, ["path", "file", "workspace_path"]);
    const size = formatBytes(p.size || p.size_bytes || p.bytes);
    const action = pickText(p, ["action", "operation", "status"]) || "已更新";
    if (path && size) return path + " · " + size + " · " + action;
    if (path) return path + " · " + action;
    const files = p.files || p.entries || p.paths;
    if (Array.isArray(files) && files.length) return "已更新 " + files.length + " 个 workspace 文件：" + summarizeObject(files);
    return summarizeObject(p, "工作区已更新。");
  }

  function taskCompletionDetail(payload) {
    const p = payload || {};
    const summary = p.final_output_summary || p.summary;
    if (summary && typeof summary === "object") {
      const type = summary.content_type || summary.type || "output";
      const chars = summary.chars ? " · " + summary.chars + " chars" : "";
      const keys = Array.isArray(summary.keys) && summary.keys.length ? " · 字段：" + summary.keys.slice(0, 4).join("、") : "";
      return "任务已完成，输出类型：" + type + chars + keys;
    }
    return pickText(p, ["message", "display_message"]) || "任务已完成，最终输出已写入对话。";
  }

  function runtimeUpdateDetail(payload) {
    const p = payload || {};
    return pickText(p, ["message", "display_message", "status", "phase", "state"]) || summarizeObject(p, "运行状态已更新。");
  }

  function eventToConversationItem(row) {
    const p = row.payload || {};
    if (row.event === "message_delta") return null;
    if (row.event === "model_thinking") return null;
    if (row.event === "task_started") return { type: "status", status: "running", severity: "info", title: "Task started", detail: "正在运行 task " + shortId(taskIdFromRow(row)) + "。", primaryMeta: "run step" };
    if (row.event === "task_resumed") return { type: "status", status: "completed", severity: "success", title: "Task resumed", detail: pickText(p, ["message", "display_message"]) || "已收到你的回复，继续执行。", primaryMeta: "resume" };
    if (row.event === "task_cancelled") return { type: "status", status: "failed", severity: "error", title: "Task cancelled", detail: pickText(p, ["reason", "message"]) || "任务已停止。", primaryMeta: "cancelled" };
    if (row.event === "tool_call_started") return { type: "tool", status: "running", severity: "info", title: toolNameFromPayload(p), eyebrow: "Tool", detail: toolDetail(p, "started"), primaryMeta: "tool_call_started" };
    if (row.event === "tool_call_completed") return { type: "tool", status: "completed", severity: "success", title: toolNameFromPayload(p), eyebrow: "Tool", detail: toolDetail(p, "completed"), primaryMeta: pathFromPayload(p) || "tool result" };
    if (row.event === "tool_call_failed") return { type: "tool error", status: "failed", severity: "error", title: toolNameFromPayload(p), eyebrow: "Tool failed", detail: toolDetail(p, "failed"), primaryMeta: "tool error" };
    if (row.event === "workspace_update") return { type: "workspace", status: "completed", severity: "success", title: "Workspace update", detail: workspaceDetail(p), primaryMeta: pathFromPayload(p) || "workspace" };
    if (row.event === "task_waiting") return { type: "waiting", status: "waiting", severity: "warning", title: "Agent needs input", detail: waitingPromptFallback(p.prompt || p.question || p.display_message || p.message || "Agent 正在等待输入", p), primaryMeta: "checkpoint", action: "回答这个问题" };
    if (row.event === "task_completed") return { type: "completion", status: "completed", severity: "success", title: "Task completed", detail: taskCompletionDetail(p), primaryMeta: "done" };
    if (row.event === "task_failed") return { type: "error", status: "failed", severity: "error", title: "Task failed", detail: errorTextFromPayload(p), primaryMeta: "failure" };
    if (row.event === "policy_denied") return { type: "policy", status: "failed", severity: "error", title: "Policy denied", detail: errorTextFromPayload(p), primaryMeta: "policy" };
    if (row.event === "runtime_update") return { type: "status", status: "running", severity: "info", title: "Runtime update", detail: runtimeUpdateDetail(p), primaryMeta: "runtime" };
    return null;
  }

  function updateRunSummary(group) {
    if (!group) return;
    const items = Array.from(group.list.querySelectorAll(".run-event"));
    const tools = items.filter((item) => item.classList.contains("tool")).length;
    const workspaces = items.filter((item) => item.classList.contains("workspace")).length;
    group.summaryText.textContent = "运行过程 · " + items.length + " events" + (tools ? " · " + tools + " tools" : "") + (workspaces ? " · " + workspaces + " workspace" : "");
    if (items.some((item) => item.classList.contains("waiting"))) group.summaryState.textContent = "waiting";
    else if (items.some((item) => item.classList.contains("failed") || item.classList.contains("policy"))) group.summaryState.textContent = "failed";
    else if (items.some((item) => item.classList.contains("completion"))) group.summaryState.textContent = "done";
    else group.summaryState.textContent = "live";
  }

  function renderConversationEvent(row, assistantWrap) {
    const item = eventToConversationItem(row);
    if (!item) return;
    const taskId = taskIdFromRow(row);
    const group = ensureRunGroup(taskId, assistantWrap);
    if (!group) return;
    const key = eventDedupeKey(row);
    if (group.itemKeys.has(key)) return;
    group.itemKeys.add(key);
    const node = document.createElement("button");
    node.type = "button";
    node.className = "run-event cursor-pointer " + item.type + " " + item.status;
    if (item.severity) node.classList.add(item.severity);
    node.id = eventDomId(row);
    node.dataset.eventKey = key;

    const icon = document.createElement("span");
    icon.className = "run-event-icon";
    icon.setAttribute("aria-hidden", "true");
    icon.textContent = item.type.includes("tool") ? "T" : item.type === "thinking" ? "·" : item.type === "workspace" ? "F" : item.type === "waiting" ? "?" : item.status === "failed" ? "!" : "✓";

    const main = document.createElement("span");
    main.className = "run-event-main";
    const top = document.createElement("span");
    top.className = "run-event-top";
    const eyebrow = document.createElement("span");
    eyebrow.className = "run-event-eyebrow";
    eyebrow.textContent = item.eyebrow || eventTitle(row.event, row.payload);
    const status = document.createElement("span");
    status.className = "run-event-status";
    status.textContent = item.status;
    top.append(eyebrow, status);

    const titleRow = document.createElement("span");
    titleRow.className = "run-event-title-row";
    const title = document.createElement("strong");
    title.textContent = item.title;
    titleRow.appendChild(title);
    if (item.primaryMeta) {
      const primaryMeta = document.createElement("code");
      primaryMeta.className = "run-event-primary-meta";
      primaryMeta.textContent = item.primaryMeta;
      titleRow.appendChild(primaryMeta);
    }

    const detail = document.createElement("span");
    detail.className = "run-event-detail";
    detail.textContent = item.detail || "查看 Inspector 了解详情。";
    const meta = document.createElement("span");
    meta.className = "run-event-meta";
    meta.textContent = "#" + (rowSequence(row) || group.itemKeys.size) + " · " + row.event;
    main.append(top, titleRow, detail, meta);

    node.append(icon, main);
    if (item.action) {
      const action = document.createElement("span");
      action.className = "run-event-action";
      action.textContent = item.action;
      node.appendChild(action);
    }
    node.addEventListener("click", () => {
      group.list.querySelectorAll(".run-event.active").forEach((active) => active.classList.remove("active"));
      node.classList.add("active");
      setRawDetail(row.raw);
      if (row.event === "workspace_update") void renderWorkspace();
      if (row.event === "task_waiting") focusWaitingInput();
    });
    group.list.appendChild(node);
    updateRunSummary(group);
    scrollMessages();
  }

  function renderConversationEventsFromState(assistantWrap) {
    state.runGroups = new Map();
    el.messages.querySelectorAll(".run-events").forEach((node) => node.remove());
    const wrap = assistantWrap || el.messages.querySelector(".message-card.assistant:last-of-type");
    state.activeAssistantWrap = wrap;
    state.events.forEach((row) => renderConversationEvent(row, wrap));
  }

  function askUserQuestionFromPayload(payload) {
    const p = payload || {};
    const args = p.args_preview || p.args || {};
    if (p.tool_name !== "ask_user" && p.name !== "ask_user") return "";
    return text(args.question || args.prompt || p.question || p.prompt).trim();
  }

  function genericWaitingMessage(value) {
    const normalized = text(value).trim().toLowerCase();
    return (
      !normalized ||
      normalized === "waiting for user input" ||
      normalized === "waiting for input" ||
      normalized === "waiting for approval" ||
      normalized === "agent 正在等待输入"
    );
  }

  function waitingMeta(payload) {
    const p = payload || {};
    const details = p.details || {};
    return {
      waitType: text(p.wait_type || details.wait_type || "unknown").trim() || "unknown",
      source: text(p.source || details.source || p.dependency || details.dependency || "unknown").trim() || "unknown",
      dependency: text(p.dependency || details.dependency || "unknown").trim() || "unknown",
      errorCode: text(p.error_code || details.error_code || details.model_error_category || "").trim(),
      message: text(p.display_message || details.display_message || p.message || details.message || "").trim(),
    };
  }

  function waitingPromptFallback(prompt, payload) {
    const value = text(prompt).trim();
    const meta = waitingMeta(payload);
    if (meta.waitType === "platform_recovery" && meta.dependency === "llm_gateway") {
      if (meta.errorCode === "model_timeout") return "模型流式输出超时，任务已暂停等待恢复决策。";
      return "模型服务暂时不可用，任务已暂停等待恢复决策。";
    }
    if (!genericWaitingMessage(value)) return value;
    if (meta.waitType === "user_clarification" && meta.source === "RuntimeErrorBase") {
      return "Agent 请求人工确认：是否允许继续执行它刚才说明的操作？";
    }
    if (meta.waitType === "user_authorization") {
      return "Agent 正在等待授权或批准。";
    }
    if (meta.waitType === "external_result") {
      return "Agent 正在等待外部系统、审批或回调结果。";
    }
    return "Agent 正在等待你补充信息。";
  }

  function waitingSuggestionFor(payload) {
    const meta = waitingMeta(payload);
    if (meta.waitType === "platform_recovery" && meta.dependency === "llm_gateway") {
      return "这不是业务澄清，而是模型网关/流式连接恢复问题。可以点击“重试模型调用”，稍后再试，或先切换模型/增大 stream_chunk_timeout 后再 resume。";
    }
    if (meta.waitType === "user_clarification" && meta.source === "RuntimeErrorBase") {
      return "如果你同意它运行安装/脚本/文件生成等操作，点击“批准继续”；如果不同意，点击“拒绝/停止”；如果要限制范围，请在自定义输入中说明。";
    }
    if (meta.waitType === "user_authorization") {
      return "请说明是否授权、授权范围或登录/授权是否已经完成。";
    }
    if (meta.waitType === "external_result") {
      return "请粘贴外部审批、回调、工单或系统返回结果。";
    }
    return "如果只是确认继续，可点击“继续执行”；如果要改变方向，请在自定义输入中写明目标、范围、输出格式或约束。";
  }

  function renderWaitingPrompt(prompt, payload, agentText) {
    const value = waitingPromptFallback(prompt, payload);
    const meta = waitingMeta(payload);
    el.waitingTitle.textContent = value;
    el.waitingKind.textContent = meta.waitType;
    el.waitingSource.textContent = meta.source;
    el.waitingSuggestion.textContent = waitingSuggestionFor(payload);
    el.waitingPayload.textContent = asJson(payload || {});
    const isModelRecovery = meta.waitType === "platform_recovery" && meta.dependency === "llm_gateway";
    document.querySelectorAll("[data-waiting-reply]").forEach((button) => {
      const action = button.getAttribute("data-waiting-action") || "";
      if (action === "approve") button.textContent = isModelRecovery ? "重试模型调用" : "批准继续";
      if (action === "continue") button.textContent = isModelRecovery ? "稍后重试" : "继续执行";
      if (action === "reject") button.textContent = isModelRecovery ? "停止任务" : "拒绝/停止";
      if (action === "approve") button.setAttribute("data-waiting-reply", isModelRecovery ? "模型流式输出超时，请重试当前模型调用并继续任务。" : "批准，继续执行。");
      if (action === "continue") button.setAttribute("data-waiting-reply", isModelRecovery ? "稍后重试模型调用。" : "继续执行。");
      if (action === "reject") button.setAttribute("data-waiting-reply", isModelRecovery ? "停止当前任务；模型流式输出超时，需要调整模型或 stream_chunk_timeout 后再重跑。" : "不批准，请停止当前执行并说明还需要哪些信息。");
    });
    const agentNote = text(agentText).trim();
    el.waitingAgentNote.hidden = !agentNote;
    el.waitingAgentText.textContent = agentNote;
    el.waitingInput.placeholder = isModelRecovery ? "例如：重试当前模型调用。 / 我已切换模型，请继续。 / 停止任务，稍后重跑。" : "例如：批准，继续执行。 / 不批准，请停止。 / 只允许生成文档，不要安装依赖。";
    el.waitingInput.setAttribute("aria-label", value + " " + el.waitingSuggestion.textContent);
    return value;
  }

  function addAskUserHint(wrap) {
    if (!wrap || wrap.querySelector(".ask-user-hint")) return;
    wrap.classList.add("ask-user");
    const hint = document.createElement("div");
    hint.className = "tool-line ask-user-hint";
    hint.textContent = "Agent 需要你在下方等待输入框中回答这个问题，然后点击“继续当前 task”。";
    const button = document.createElement("button");
    button.type = "button";
    button.className = "focus-waiting-button cursor-pointer";
    button.textContent = "回答这个问题";
    button.addEventListener("click", focusWaitingInput);
    wrap.append(hint, button);
  }

  function showAskUserPrompt(assistant, prompt) {
    const value = text(prompt).trim();
    if (!value) return;
    if (assistant && assistant.body && !assistant.body.textContent.trim()) {
      assistant.body.textContent = value;
      addAskUserHint(assistant.wrap);
      scrollMessages();
      return;
    }
    const card = appendMessage("assistant", value);
    addAskUserHint(card.wrap);
    scrollMessages();
  }

  function persistMessages() {
    if (!state.sessionId || !st()) return;
    const rows = [];
    el.messages.querySelectorAll(".message-card").forEach((card) => {
      const body = card.querySelector(".message-body");
      if (!body) return;
      const role = card.classList.contains("user") ? "user" : "assistant";
      rows.push({ role, text: body.textContent, ts: Date.now() });
    });
    st().setMessages(state.sessionId, rows);
    st().touchSession(state.sessionId, { agentId: el.agentSelect.value }, { preserveUpdatedAt: true });
  }

  function normalizeStoredMessages(data) {
    const fromMessages = Array.isArray(data && data.messages) ? data.messages : [];
    if (fromMessages.length) {
      return fromMessages
        .slice()
        .sort((a, b) => Date.parse(a.created_at || "") - Date.parse(b.created_at || ""))
        .map((message) => ({
          role: message.role === "user" ? "user" : "assistant",
          text: formatTaskOutput(message.content),
          ts: Date.parse(message.created_at || "") || Date.now(),
        }))
        .filter((message) => message.text);
    }
    const tasks = Array.isArray(data && data.tasks) ? data.tasks : [];
    return synthesizeMessagesFromTasks(tasks);
  }

  function renderMessagesFromStore() {
    emptyMessages();
    if (!state.sessionId || !st()) return;
    const rows = st().getMessages(state.sessionId);
    if (!rows.length) return;
    el.messages.innerHTML = "";
    rows.forEach((m) => appendMessage(m.role === "user" ? "user" : "assistant", m.text || ""));
  }

  function formatTaskOutput(value) {
    if (value == null) return "";
    if (typeof value === "string") return value;
    try {
      return JSON.stringify(value, null, 2);
    } catch {
      return text(value);
    }
  }

  function synthesizeMessagesFromTasks(tasks) {
    const rows = [];
    tasks.forEach((task) => {
      const startedAt = Date.parse(task.started_at || task.created_at || "") || Date.now();
      const finishedAt = Date.parse(task.finished_at || task.completed_at || task.updated_at || "") || startedAt;
      rows.push({ role: "user", text: task.input_summary || "(无输入摘要)", ts: startedAt });
      const assistantText = formatTaskOutput(task.final_output) || (task.error ? formatTaskOutput(task.error) : "");
      if (assistantText) rows.push({ role: "assistant", text: assistantText, ts: finishedAt });
    });
    return rows;
  }

  function hydrateSessionMessagesFromState(data) {
    if (!state.sessionId || !st()) return;
    const rows = normalizeStoredMessages(data);
    if (!rows.length) return;
    st().setMessages(state.sessionId, rows);
    renderMessagesFromStore();
  }

  function scrollMessages() {
    el.messages.scrollTop = el.messages.scrollHeight;
  }

  function reducedMotionPreferred() {
    return Boolean(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  }

  function focusWaitingInput() {
    if (el.waitingPanel && !el.waitingPanel.hidden) {
      el.waitingPanel.scrollIntoView({ block: "nearest", behavior: reducedMotionPreferred() ? "auto" : "smooth" });
    }
    el.waitingInput.focus();
  }

  function setWaitingUi(isWaiting) {
    if (el.runConsole) el.runConsole.classList.toggle("waiting-active", Boolean(isWaiting));
    el.waitingPanel.hidden = !isWaiting;
  }

  function closeStream() {
    if (state.eventSource) {
      state.eventSource.close();
      state.eventSource = null;
    }
  }

  function resetRunView(keepMessages) {
    closeStream();
    setBusy(false);
    state.activeTaskId = null;
    state.waitingTaskId = null;
    state.pendingAskUserPrompt = "";
    state.waitingPayload = null;
    state.waitingAgentText = "";
    state.currentTraceId = "";
    state.currentError = null;
    state.events = [];
    state.failures = 0;
    state.runGroups = new Map();
    state.activeAssistantWrap = null;
    el.errorStack.innerHTML = "";
    el.messages.querySelectorAll(".run-events").forEach((node) => node.remove());
    setWaitingUi(false);
    if (state.sessionId && st() && st().setEvents) st().setEvents(state.sessionId, []);
    renderEvents();
    setRawDetail("选择事件、加载 state 或发生错误后显示详情。");
    if (!keepMessages) emptyMessages();
    updateInspector();
  }

  function renderSessionList() {
    const list = st()
      .loadIndex()
      .slice()
      .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    el.sessionList.innerHTML = "";
    if (!list.length) {
      const empty = document.createElement("div");
      empty.className = "event-empty";
      empty.textContent = "暂无会话。";
      el.sessionList.appendChild(empty);
      return;
    }
    list.forEach((entry) => {
      const card = document.createElement("article");
      card.className = "session-card cursor-pointer" + (entry.sessionId === state.sessionId ? " active" : "");
      card.setAttribute("role", "option");
      card.setAttribute("aria-selected", entry.sessionId === state.sessionId ? "true" : "false");
      card.tabIndex = 0;
      const title = document.createElement("p");
      title.className = "session-name";
      title.textContent = entry.title || "未命名测试会话";
      const meta = document.createElement("p");
      meta.className = "session-meta";
      meta.textContent = shortId(entry.sessionId) + (entry.agentId ? " · " + entry.agentId : "");
      card.append(title, meta);
      card.addEventListener("click", () => void selectSession(entry.sessionId));
      card.addEventListener("keydown", (ev) => {
        if (ev.key === "Enter" || ev.key === " ") {
          ev.preventDefault();
          void selectSession(entry.sessionId);
        }
      });
      el.sessionList.appendChild(card);
    });
  }

  async function mergeRemoteSessions() {
    const remote = await fetchJson("/sessions", { method: "GET" });
    remote.forEach((session) => {
      st().upsertEntry({
        sessionId: session.session_id,
        title: session.title || "远程测试会话",
        updatedAt: Date.parse(session.updated_at || "") || Date.now(),
      });
    });
    renderSessionList();
  }

  async function createSession() {
    setStatus("creating", "创建测试会话…");
    const title = selectedAgentName() + " · Test · " + new Date().toLocaleString("zh-CN", { hour12: false });
    const session = await fetchJson("/sessions", {
      method: "POST",
      body: JSON.stringify({ title, trust_level: selectedAgentTrustLevel() }),
    });
    st().upsertEntry({
      sessionId: session.session_id,
      title: session.title || title,
      agentId: el.agentSelect.value || null,
    });
    await selectSession(session.session_id);
    setStatus("idle", "会话已创建");
  }

  async function selectSession(id) {
    persistMessages();
    resetRunView(true);
    state.sessionId = id;
    st().setCurrentSessionId(id);
    const entry = st().loadIndex().find((item) => item.sessionId === id);
    if (entry && entry.agentId && Array.from(el.agentSelect.options).some((opt) => opt.value === entry.agentId)) {
      el.agentSelect.value = entry.agentId;
    }
    renderMessagesFromStore();
    state.activeAssistantWrap = el.messages.querySelector(".message-card.assistant:last-of-type");
    renderEventsFromStore();
    renderSessionList();
    updateIdentity();
    void renderWorkspace();
    try {
      await hydrateSessionWaitingState({ clearWhenNone: true });
      if (state.activeTaskId) void loadTaskEvents({ silent: true });
    } catch {
      /* Session hydration is best-effort; manual State remains available. */
      if (state.activeTaskId) void loadTaskEvents({ silent: true });
    }
    if (!state.waitingTaskId) setStatus("idle", "会话就绪");
  }

  async function bootSessions() {
    const legacy = sessionStorage.getItem(LEGACY_SESSION);
    if (legacy && st().loadIndex().length === 0) {
      st().upsertEntry({ sessionId: legacy, title: "迁移测试会话" });
      sessionStorage.removeItem(LEGACY_SESSION);
    }
    try {
      await mergeRemoteSessions();
    } catch (error) {
      showRuntimeError(error, "刷新服务器会话失败", { recover: "仍可使用本地缓存中的会话，或稍后重试刷新。" });
    }
    const list = st().loadIndex();
    let current = st().getCurrentSessionId();
    if (!list.length) {
      await createSession();
      return;
    }
    if (!current || !list.some((item) => item.sessionId === current)) current = list[0].sessionId;
    await selectSession(current);
  }

  async function loadAgents() {
    setStatus("loading", "加载 Agent…");
    const agents = await fetchJson("/agents", { method: "GET" });
    el.agentSelect.innerHTML = "";
    if (!agents.length) {
      const option = document.createElement("option");
      option.value = "";
      option.textContent = "（无 Agent）";
      el.agentSelect.appendChild(option);
      setFieldError(el.agentError, "未找到可测试的 Agent。请先配置 Agent。致命路径：GET /agents 返回空数组。");
      return;
    }
    agents.forEach((agent) => {
      const option = document.createElement("option");
      option.value = agent.agent_id;
      option.textContent = (agent.name || agent.agent_id) + " (" + agent.agent_id + ")";
      option.title = agent.description || "";
      option.dataset.trustLevel = agent.trust_level || "verified";
      el.agentSelect.appendChild(option);
    });
    clearFieldError(el.agentError);
    setStatus("idle", "Agent 已加载");
  }

  function classifyEvent(eventName) {
    if (eventName === "tool_call_failed" || eventName === "task_failed") return "failed";
    if (eventName === "policy_denied") return "policy";
    if (eventName === "task_waiting") return "waiting";
    if (eventName === "task_completed") return "completed";
    if (eventName === "message_delta" || eventName === "model_thinking") return "model";
    if (eventName && eventName.includes("tool")) return "tool";
    return "runtime";
  }

  function eventTitle(eventName, payload) {
    const p = payload || {};
    if (eventName === "task_started") return "任务已启动";
    if (eventName === "task_completed") return "任务完成";
    if (eventName === "task_failed") return "任务失败";
    if (eventName === "task_cancelled") return "任务已取消";
    if (eventName === "task_waiting") return "等待用户输入";
    if (eventName === "policy_denied") return "策略拒绝";
    if (eventName === "tool_call_started") return "Tool 调用开始";
    if (eventName === "tool_call_completed") return "Tool 调用完成";
    if (eventName === "tool_call_failed") return "Tool 调用失败";
    return p.name || p.tool_name || eventName || "runtime event";
  }

  function eventDedupeKey(row) {
    const raw = (row && row.raw) || {};
    return [raw.task_id || raw.taskId || "", raw.sequence || "", raw.event_id || raw.eventId || "", row && row.event || "", row && row.time || ""].join("|");
  }

  function persistEvents() {
    if (!state.sessionId || !st() || !st().setEvents) return;
    st().setEvents(state.sessionId, state.events.slice(-160));
    st().touchSession(state.sessionId, { agentId: el.agentSelect.value }, { preserveUpdatedAt: true });
  }

  function renderEventsFromStore() {
    state.events = [];
    state.failures = 0;
    if (!state.sessionId || !st() || !st().getEvents) {
      renderEvents();
      return;
    }
    const rows = st().getEvents(state.sessionId);
    if (!Array.isArray(rows) || !rows.length) {
      renderEvents();
      return;
    }
    const seen = new Set();
    state.events = rows.filter((row) => {
      if (!row || !row.event) return false;
      row.kind = row.kind || classifyEvent(row.event);
      row.payload = parseMaybeJson(row.payload || (row.raw && row.raw.payload) || {});
      row.raw = row.raw || { event: row.event, payload: row.payload };
      row.time = row.time || new Date().toLocaleTimeString("zh-CN", { hour12: false });
      row.taskId = taskIdFromRow(row);
      const key = eventDedupeKey(row);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
    state.failures = state.events.filter((row) => ["failed", "policy"].includes(row.kind)).length;
    const lastWithTask = state.events.slice().reverse().find((row) => row.raw && (row.raw.task_id || row.raw.taskId));
    if (lastWithTask && !state.activeTaskId) state.activeTaskId = lastWithTask.raw.task_id || lastWithTask.raw.taskId;
    renderEvents();
    renderConversationEventsFromState();
    updateInspector();
  }

  function trackEvent(eventName, payload, raw) {
    const parsedPayload = parseMaybeJson(payload);
    const row = {
      event: eventName,
      payload: parsedPayload,
      raw: raw || { event: eventName, payload: parsedPayload },
      kind: classifyEvent(eventName),
      time: new Date().toLocaleTimeString("zh-CN", { hour12: false }),
    };
    row.taskId = taskIdFromRow(row);
    const key = eventDedupeKey(row);
    if (state.events.some((event) => eventDedupeKey(event) === key)) return row;
    state.events.push(row);
    renderConversationEvent(row, state.activeAssistantWrap);
    if (["failed", "policy"].includes(row.kind)) state.failures += 1;
    const traceId = parsedPayload && (parsedPayload.trace_id || parsedPayload.traceId || (parsedPayload.error && parsedPayload.error.trace_id));
    if (traceId) state.currentTraceId = traceId;
    const taskId = raw && (raw.task_id || raw.taskId);
    if (taskId && !state.activeTaskId) state.activeTaskId = taskId;
    if (state.events.length > 160) state.events = state.events.slice(-160);
    renderEvents();
    updateInspector();
    persistEvents();
    return row;
  }

  function renderEvents() {
    el.eventList.innerHTML = "";
    if (!state.events.length) {
      const empty = document.createElement("li");
      empty.className = "event-empty";
      empty.textContent = "暂无事件。";
      el.eventList.appendChild(empty);
      updateInspector();
      return;
    }
    state.events.forEach((event, index) => {
      if (event.event === "model_thinking") return;
      const item = document.createElement("li");
      item.className = "event-item " + event.kind;
      const button = document.createElement("button");
      button.type = "button";
      button.className = "event-button cursor-pointer";
      const title = document.createElement("div");
      title.className = "event-title";
      const name = document.createElement("span");
      name.textContent = eventTitle(event.event, event.payload);
      const chip = document.createElement("span");
      chip.className = "event-chip";
      chip.textContent = event.kind;
      title.append(name, chip);
      const meta = document.createElement("div");
      meta.className = "event-meta";
      meta.textContent = "#" + (index + 1) + " · " + event.time + " · " + event.event;
      button.append(title, meta);
      button.addEventListener("click", () => setRawDetail(event.raw));
      item.appendChild(button);
      el.eventList.appendChild(item);
    });
    el.eventList.scrollTop = el.eventList.scrollHeight;
  }

  function showRuntimeError(error, heading, options) {
    const normalized = normalizeError(error, heading || "运行失败");
    state.currentError = normalized;
    if (normalized.task_id) state.activeTaskId = normalized.task_id;
    if (normalized.details && normalized.details.active_task_id) state.activeTaskId = normalized.details.active_task_id;
    if (normalized.trace_id) state.currentTraceId = normalized.trace_id;

    const card = document.createElement("article");
    card.className = "error-card";
    card.setAttribute("role", "alert");
    const title = document.createElement("h3");
    title.textContent = heading || normalized.type || "运行失败";
    const message = document.createElement("p");
    message.textContent = normalized.message || "没有返回错误消息。";
    const recover = document.createElement("p");
    recover.textContent = options && options.recover ? options.recover : normalized.retryable ? "这是可重试错误，可以检查输入后重新运行。" : "请查看 trace、task id 和 raw detail 定位原因。";
    const meta = document.createElement("div");
    meta.className = "error-meta";
    [
      ["type", normalized.type],
      ["retryable", normalized.retryable == null ? "unknown" : String(normalized.retryable)],
      ["task", normalized.task_id || state.activeTaskId],
      ["trace", normalized.trace_id || state.currentTraceId],
    ].forEach(([key, value]) => {
      if (!value) return;
      const code = document.createElement("code");
      code.textContent = key + ": " + shortId(value);
      meta.appendChild(code);
    });
    card.append(title, message, recover, meta);
    el.errorStack.prepend(card);
    while (el.errorStack.children.length > 4) el.errorStack.lastElementChild.remove();
    appendMessage("error", (heading || "运行失败") + "\n\n" + (normalized.message || ""), { error: true });
    setRawDetail(normalized);
    updateInspector();
  }

  function buildTaskBody(input) {
    clearValidationErrors();
    if (!state.sessionId) {
      setFieldError(el.taskInputError, "请先创建或选择一个 session。这里需要 session_id 才能 POST /tasks。");
      return null;
    }
    if (!el.agentSelect.value) {
      setFieldError(el.agentError, "请选择要测试的 Agent。请求体需要 agent_id。");
      return null;
    }
    if (!input.trim()) {
      setFieldError(el.taskInputError, "请输入测试任务。空输入不会发送给 Agent。");
      return null;
    }
    const result = window.buildStartTaskBody(
      state.sessionId,
      el.agentSelect.value,
      input,
      el.dynamicContext,
      el.promptAppend,
      { metadataRaw: el.taskMetadata.value }
    );
    if (!result.ok) {
      const target = result.error && result.error.includes("dynamic_context") ? el.dynamicContextError : el.metadataError;
      setFieldError(target, result.error);
      setRawDetail({ validation_error: result.error });
      return null;
    }
    if (result.body.metadata && !isPlainObject(result.body.metadata)) {
      setFieldError(el.metadataError, "Task metadata 必须是 JSON 对象，不能是数组或字符串。");
      setRawDetail({ validation_error: "metadata must be an object", metadata: result.body.metadata });
      return null;
    }
    if (result.body.dynamic_context && !isPlainObject(result.body.dynamic_context)) {
      setFieldError(el.dynamicContextError, "dynamic_context 必须是 JSON 对象，不能是数组或字符串。");
      setRawDetail({ validation_error: "dynamic_context must be an object", dynamic_context: result.body.dynamic_context });
      return null;
    }
    const artifactKind = el.artifactRequirement.value;
    if (artifactKind && artifactKind !== "none") {
      result.body.metadata = result.body.metadata || {};
      if (result.body.metadata.runtime_acceptance && !isPlainObject(result.body.metadata.runtime_acceptance)) {
        setFieldError(el.metadataError, "metadata.runtime_acceptance 必须是 JSON 对象。");
        setRawDetail({ validation_error: "metadata.runtime_acceptance must be an object" });
        return null;
      }
      result.body.metadata.runtime_acceptance = buildRuntimeAcceptance(artifactKind);
    }
    result.body.workspace_id = workspaceId();
    return result.body;
  }

  function buildRuntimeAcceptance(kind) {
    return {
      required_files: [
        {
          path: "*." + kind,
          type: kind,
          min_size_bytes: kind === "pdf" ? 512 : 1024,
        },
      ],
    };
  }

  function attachExtraEventTracking(es, taskId) {
    ["task_resumed", "workspace_update", "runtime_update", "model_thinking"].forEach((eventName) => {
      es.addEventListener(eventName, (ev) => {
        const data = readEventData(ev);
        trackEvent(eventName, data.payload || {}, { ...data, event: eventName, task_id: data.task_id || taskId });
      });
    });
  }

  function subscribeTaskStream(taskId, assistantBody, assistantWrap, options) {
    closeStream();
    options = options || {};
    let url = apiBase() + "/tasks/" + encodeURIComponent(taskId) + "/stream";
    if (options.afterSequence != null) url += "?after_sequence=" + encodeURIComponent(String(options.afterSequence));
    state.eventSource = window.attachTaskEventSource(url, {
      taskId,
      assistantBody,
      assistantWrap,
      appendToolLine,
      setStatus: (message) => {
        const value = text(message);
        if (!value) {
          setStatus(state.currentError ? "failed" : "idle", state.currentError ? "任务失败" : "准备就绪");
          return;
        }
        if (value.includes("完成")) setStatus("completed", value);
        else if (value.includes("等待")) setStatus("waiting", value);
        else setStatus("streaming", value);
      },
      showError: (message) => {
        if (!message) return;
        const currentMessage = state.currentError && state.currentError.message;
        if (currentMessage && (currentMessage === message || currentMessage.includes(message))) return;
        showRuntimeError({ message }, "事件流错误", { recover: "检查 SSE 连接、后端日志或重试当前输入。" });
      },
      setBusy,
      setActiveTaskId: (value) => {
        if (value) state.activeTaskId = value;
        updateInspector();
      },
      scrollMessages,
      renderMdBody: null,
      focusComposer: () => el.taskInput.focus(),
      addTimelineEvent: (eventName, payload) => {
        state.activeAssistantWrap = assistantWrap;
        trackEvent(eventName, payload, { event: eventName, payload, task_id: taskId });
        if (eventName === "task_failed") {
          showRuntimeError(payload && payload.error ? payload.error : payload, "Task failed", { recover: "查看错误 details 与事件流，修正输入后可重跑上次任务。" });
          setStatus("failed", "任务失败");
        }
        if (eventName === "policy_denied") {
          showRuntimeError(payload, "Policy denied", { recover: "检查策略限制、权限 scope 或请求内容。" });
          setStatus("denied", "策略拒绝");
        }
        if (eventName === "task_completed") {
          setStatus("completed", "任务完成");
          void renderWorkspace();
        }
        if (eventName === "workspace_update") void renderWorkspace();
        if (eventName === "task_failed") void renderWorkspace();
        if (eventName === "task_cancelled") setStatus("cancelled", "任务已取消");
        if (eventName === "tool_call_started") {
          const question = askUserQuestionFromPayload(payload);
          if (question) {
            state.pendingAskUserPrompt = question;
            showAskUserPrompt({ body: assistantBody, wrap: assistantWrap }, question);
          }
        }
        return payload;
      },
      onStreamFinal: () => {
        assistantWrap.classList.remove("streaming", "msg-streaming");
        persistMessages();
      },
      onWaitingInput: (tid, prompt, payload, data) => {
        state.waitingTaskId = tid;
        state.waitingPayload = payload || {};
        state.waitingSequence = data && data.sequence != null ? data.sequence : (payload && payload.event_sequence != null ? payload.event_sequence : null);
        state.waitingAgentText = text(assistantBody.textContent).trim();
        const question = renderWaitingPrompt(prompt || state.pendingAskUserPrompt || "Agent 正在等待输入", payload, state.waitingAgentText);
        showAskUserPrompt({ body: assistantBody, wrap: assistantWrap }, question);
        el.waitingInput.value = "";
        setRawDetail({ waiting_input: payload || {}, suggested_reply: el.waitingSuggestion.textContent });
        setWaitingUi(true);
        focusWaitingInput();
        state.pendingAskUserPrompt = "";
        setStatus("waiting", "等待用户输入");
        void renderWorkspace();
        persistMessages();
      },
    });
    attachExtraEventTracking(state.eventSource, taskId);
  }

  async function sendMessage(inputOverride) {
    const input = text(inputOverride != null ? inputOverride : el.taskInput.value).trim();
    el.errorStack.innerHTML = "";
    const body = buildTaskBody(input);
    if (!body) return;
    state.lastInput = input;
    try {
      await hydrateSessionWaitingState({ clearWhenNone: false });
    } catch {
      /* fall back to local waiting state below */
    }
    if (state.waitingTaskId) {
      void resumeWaiting(input);
      return;
    }
    const displayBody = redactRequestForDisplay(body);
    state.lastRequestBody = displayBody;
    state.events = [];
    state.failures = 0;
    state.currentError = null;
    state.pendingAskUserPrompt = "";
    state.waitingPayload = null;
    state.waitingAgentText = "";
    state.currentTraceId = "";
    renderEvents();
    setRawDetail({ request: displayBody });
    updateInspector();

    el.taskInput.value = "";
    appendMessage("user", input);
    const assistant = appendMessage("assistant", "", { streaming: true });
    state.activeAssistantWrap = assistant.wrap;
    persistMessages();
    st().touchSession(state.sessionId, { agentId: el.agentSelect.value });
    renderSessionList();
    setBusy(true);
    setStatus("posting", "POST /tasks …");

    try {
      const task = await fetchJson("/tasks", { method: "POST", body: JSON.stringify(body) });
      state.activeTaskId = task.task_id;
      state.currentTraceId = task.trace_id || task.correlation_id || "";
      el.btnRetry.disabled = false;
      updateInspector();
      setStatus("streaming", "连接 SSE stream …");
      subscribeTaskStream(task.task_id, assistant.body, assistant.wrap);
    } catch (error) {
      assistant.wrap.classList.remove("streaming", "msg-streaming");
      const normalized = normalizeError(error);
      const activeTaskId = normalized.details && normalized.details.active_task_id;
      if ((normalized.type === "session_busy" || normalized.message.includes("active foreground task")) && activeTaskId) {
        state.activeTaskId = activeTaskId;
        try {
          await hydrateSessionWaitingState({ clearWhenNone: false });
        } catch {
          /* keep original error if hydration fails */
        }
      }
      assistant.body.textContent = "启动失败：\n\n" + normalized.message;
      showRuntimeError(error, "POST /tasks 失败", { recover: "如果这是 waiting_input，请使用等待面板或主输入框继续；否则检查 agent_id、session_id、权限 scope 和请求 JSON 后重试。" });
      setBusy(false);
      setStatus(state.waitingTaskId ? "waiting" : "failed", state.waitingTaskId ? "等待用户输入" : "启动失败");
      persistMessages();
    }
  }

  async function cancelTask() {
    if (!state.activeTaskId) return;
    try {
      setStatus("cancelling", "取消任务…");
      await fetchJson("/tasks/" + encodeURIComponent(state.activeTaskId) + "/cancel", { method: "POST" });
      setStatus("cancelled", "取消请求已发送");
    } catch (error) {
      showRuntimeError(error, "取消任务失败", { recover: "任务可能已经结束，尝试拉取事件确认最终状态。" });
      setStatus("failed", "取消失败");
    }
  }

  async function resumeWaiting(inputOverride) {
    clearFieldError(el.waitingError);
    const input = text(inputOverride != null ? inputOverride : el.waitingInput.value).trim();
    if (!state.waitingTaskId) return;
    if (!input) {
      setFieldError(el.waitingError, "请输入继续任务所需的信息。空回复不会 resume task。");
      return;
    }
    appendMessage("user", input);
    const assistant = appendMessage("assistant", "", { streaming: true });
    state.activeAssistantWrap = assistant.wrap;
    persistMessages();
    setWaitingUi(false);
    setBusy(true);
    setStatus("resuming", "POST /tasks/…/resume …");
    const tid = state.waitingTaskId;
    try {
      const built = window.buildResumeTaskBody(input, el.dynamicContext, el.promptAppend, { metadataRaw: el.taskMetadata.value });
      if (!built.ok) {
        const target = built.error && built.error.includes("dynamic_context") ? el.dynamicContextError : el.metadataError;
        setFieldError(target, built.error);
        throw new Error(built.error);
      }
      state.lastRequestBody = built.body;
      el.requestJson.textContent = asJson(built.body);
      updateInspector();
      await fetchJson("/tasks/" + encodeURIComponent(tid) + "/resume", {
        method: "POST",
        body: JSON.stringify(built.body),
      });
      state.waitingTaskId = null;
      state.activeTaskId = tid;
      subscribeTaskStream(tid, assistant.body, assistant.wrap, { afterSequence: state.waitingSequence });
      state.waitingSequence = null;
    } catch (error) {
      assistant.wrap.classList.remove("streaming", "msg-streaming");
      assistant.body.textContent = "恢复失败：\n\n" + normalizeError(error).message;
      showRuntimeError(error, "Resume task 失败", { recover: "该 task 当前不可继续。请点击 State 刷新状态；如果 task 已完成、失败或取消，需要重新发起任务。" });
      setBusy(false);
      setWaitingUi(true);
      setStatus("failed", "恢复失败");
      persistMessages();
    }
  }

  function applyQuickReply(value) {
    const reply = text(value).trim();
    if (!reply) return;
    el.waitingInput.value = reply;
    el.waitingInput.focus();
  }

  function hydrateWaitingFromTask(task, sourcePayload) {
    if (!task || task.status !== "waiting_input") return false;
    const payload = sourcePayload || task.interrupt_payload || {};
    const prompt = waitingPromptFallback(
      payload.prompt || payload.question || payload.display_message || payload.message || "Agent 正在等待输入",
      payload
    );
    state.activeTaskId = task.task_id || state.activeTaskId;
    state.waitingTaskId = task.task_id || state.waitingTaskId;
    state.waitingPayload = payload;
    state.waitingAgentText = "";
    state.waitingSequence = payload.event_sequence != null ? payload.event_sequence : null;
    renderWaitingPrompt(prompt, payload, "");
    setRawDetail({
      waiting_input: payload,
      task_id: state.waitingTaskId,
      resumable: task.resumable !== false,
      resume_after_restart: !!task.resume_after_restart,
      suggested_reply: el.waitingSuggestion.textContent,
    });
    setWaitingUi(true);
    setStatus("waiting", "等待用户输入");
    updateInspector();
    return true;
  }

  function activeWaitingTaskFromState(data) {
    const active = activeSessionTaskFromState(data);
    return active && active.status === "waiting_input" ? active : null;
  }

  function activeSessionTaskFromState(data) {
    const tasks = Array.isArray(data && data.tasks) ? data.tasks : [];
    if (window.findActiveSessionTask) return window.findActiveSessionTask(data);
    for (let i = tasks.length - 1; i >= 0; i -= 1) {
      if (tasks[i] && ["pending", "running", "waiting_input"].includes(tasks[i].status)) return tasks[i];
    }
    return null;
  }

  function hydrateRunningTaskFromState(task) {
    if (!task || !["pending", "running"].includes(task.status)) return false;
    state.activeTaskId = task.task_id || state.activeTaskId;
    state.waitingTaskId = null;
    state.waitingPayload = null;
    setWaitingUi(false);
    setBusy(true);
    setStatus("streaming", task.status === "pending" ? "任务已恢复：等待运行…" : "任务已恢复：运行中…");
    updateInspector();
    const assistant = appendMessage("assistant", "页面刷新后已恢复正在运行的任务，正在重新连接事件流…", { streaming: true });
    state.activeAssistantWrap = assistant.wrap;
    renderConversationEventsFromState(assistant.wrap);
    subscribeTaskStream(state.activeTaskId, assistant.body, assistant.wrap);
    return true;
  }

  async function hydrateSessionWaitingState(options) {
    if (!state.sessionId) return null;
    const data = await fetchJson("/sessions/" + encodeURIComponent(state.sessionId) + "/state", { method: "GET" });
    hydrateSessionMessagesFromState(data);
    const activeTask = activeSessionTaskFromState(data);
    const waitingTask = activeTask && activeTask.status === "waiting_input" ? activeTask : null;
    const runningTask = activeTask && ["pending", "running"].includes(activeTask.status) ? activeTask : null;
    if (waitingTask) hydrateWaitingFromTask(waitingTask);
    else if (runningTask) hydrateRunningTaskFromState(runningTask);
    else if (options && options.clearWhenNone) {
      state.waitingTaskId = null;
      state.waitingPayload = null;
      state.waitingSequence = null;
      setWaitingUi(false);
    }
    return { data, waitingTask, runningTask, activeTask };
  }

  async function loadSessionState() {
    if (!state.sessionId) return;
    try {
      setStatus("loading", "加载 session state …");
      const result = await hydrateSessionWaitingState({ clearWhenNone: true });
      setRawDetail(result ? result.data : {});
      const hasWaiting = result && result.waitingTask;
      const hasRunning = result && result.runningTask;
      setStatus(hasWaiting ? "waiting" : hasRunning ? "streaming" : "idle", hasWaiting ? "Session state 已加载：发现 waiting_input" : hasRunning ? "Session state 已加载：已恢复运行中 task" : "Session state 已加载");
    } catch (error) {
      showRuntimeError(error, "加载 session state 失败", { recover: "确认 session 仍存在且当前用户有读取权限。" });
      setStatus("failed", "加载失败");
    }
  }

  async function loadTaskEvents(options) {
    options = options || {};
    if (!state.activeTaskId) return;
    try {
      if (!options.silent) setStatus("loading", "拉取 task events …");
      if (options.replace) {
        state.events = [];
        state.failures = 0;
        renderEvents();
      }
      const data = await fetchJson("/tasks/" + encodeURIComponent(state.activeTaskId) + "/events", { method: "GET" });
      (data.items || []).forEach((event) => trackEvent(event.event, event.payload, event));
      renderConversationEventsFromState(state.activeAssistantWrap);
      if (!options.silent) setRawDetail(data);
      if (!options.silent) setStatus("idle", "Task events 已加载");
      persistEvents();
    } catch (error) {
      if (options.silent) return;
      showRuntimeError(error, "拉取 task events 失败", { recover: "确认 task_id 正确，或使用当前事件流中的详情排查。" });
      setStatus("failed", "拉取失败");
    }
  }

  function bindEvents() {
    el.btnNewSession.addEventListener("click", () => void createSession().catch((error) => showRuntimeError(error, "创建 session 失败")));
    el.btnRefreshSessions.addEventListener("click", () => void mergeRemoteSessions().catch((error) => showRuntimeError(error, "刷新 session 失败")));
    el.btnSend.addEventListener("click", () => void sendMessage());
    el.btnCancel.addEventListener("click", () => void cancelTask());
    el.taskFiles.addEventListener("change", handleFileSelection);
    el.btnResume.addEventListener("click", () => void resumeWaiting());
    document.querySelectorAll("[data-waiting-reply]").forEach((button) => {
      button.addEventListener("click", () => applyQuickReply(button.getAttribute("data-waiting-reply")));
    });
    el.waitingInput.addEventListener("keydown", (ev) => {
      if ((ev.metaKey || ev.ctrlKey) && ev.key === "Enter") {
        ev.preventDefault();
        void resumeWaiting();
      }
    });
    el.btnRetry.addEventListener("click", () => {
      if (state.lastInput) void sendMessage(state.lastInput);
    });
    el.btnLoadSessionState.addEventListener("click", () => void loadSessionState());
    el.btnLoadEvents.addEventListener("click", () => void loadTaskEvents());
    el.btnRefreshWorkspace.addEventListener("click", () => void renderWorkspace());
    el.btnCopySession.addEventListener("click", () => copyText(state.sessionId, "session_id"));
    el.btnCopyWorkspace.addEventListener("click", () => copyText(workspaceId(), "workspace_id"));
    el.btnCopyTask.addEventListener("click", () => copyText(state.activeTaskId, "task_id"));
    el.btnCopyTrace.addEventListener("click", () => copyText(state.currentTraceId, "trace_id"));
    el.btnCopyRequest.addEventListener("click", () => copyText(asJson(state.lastRequestBody), "request body"));
    el.btnCopyRaw.addEventListener("click", () => copyText(el.rawJson.textContent, "raw detail"));
    el.agentSelect.addEventListener("change", () => {
      updateIdentity();
      if (state.sessionId) {
        st().touchSession(state.sessionId, { agentId: el.agentSelect.value });
        renderSessionList();
      }
    });
    el.artifactRequirement.addEventListener("change", updateIdentity);
    el.taskInput.addEventListener("keydown", (ev) => {
      if (ev.key === "Enter" && (ev.metaKey || ev.ctrlKey)) {
        ev.preventDefault();
        void sendMessage();
      }
    });
  }

  async function boot() {
    emptyMessages();
    renderEvents();
    setUploadSummary("上传到 workspace uploads/", "idle");
    updateInspector();
    bindEvents();
    try {
      await loadAgents();
      await bootSessions();
      updateIdentity();
      if (!state.activeTaskId && !state.waitingTaskId) setStatus("idle", "准备就绪");
    } catch (error) {
      showRuntimeError(error, "控制台启动失败", { recover: "检查后端服务、/agents 和 /sessions 是否可用。" });
      setStatus("failed", "启动失败");
    }
  }

  void boot();
})();
