-- Spec 2026-05-08 §4.4 — one active foreground task per session.
--
-- Historical local/dev databases can contain multiple foreground tasks left in
-- active states before the runtime-level guard existed. Normalize those stale
-- duplicates before creating the partial unique index: keep the newest active
-- task per session and mark older duplicates as cancelled. This preserves the
-- current in-flight task while making the migration idempotent on existing data.

WITH ranked AS (
    SELECT
        task_id,
        ROW_NUMBER() OVER (
            PARTITION BY session_id
            ORDER BY COALESCE(started_at, finished_at, NOW()) DESC, task_id DESC
        ) AS rn
    FROM tasks
    WHERE status IN ('pending', 'running', 'waiting_input')
      AND COALESCE((metadata ->> 'background')::boolean, false) = false
)
UPDATE tasks
SET
    status = 'cancelled',
    finished_at = COALESCE(finished_at, NOW()),
    error = COALESCE(
        error,
        '{"type":"MigrationCancelled","message":"Cancelled stale duplicate active foreground task before creating session active-task guard."}'::jsonb
    )
FROM ranked
WHERE tasks.task_id = ranked.task_id
  AND ranked.rn > 1;

CREATE UNIQUE INDEX IF NOT EXISTS tasks_one_active_foreground_per_session_uq
    ON tasks(session_id)
    WHERE status IN ('pending', 'running', 'waiting_input')
      AND COALESCE((metadata ->> 'background')::boolean, false) = false;
