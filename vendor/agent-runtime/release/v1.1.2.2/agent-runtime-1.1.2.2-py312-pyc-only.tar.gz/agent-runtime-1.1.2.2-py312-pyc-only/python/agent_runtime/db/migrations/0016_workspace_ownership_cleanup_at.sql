ALTER TABLE workspace_ownership
    ADD COLUMN IF NOT EXISTS cleanup_at TIMESTAMPTZ;
