ALTER TABLE tasks
    ADD COLUMN IF NOT EXISTS run_kind TEXT NOT NULL DEFAULT 'session_run'
        CHECK (run_kind IN ('session_run','scheduled_run','manual_shortcut')),
    ADD COLUMN IF NOT EXISTS persistence TEXT NOT NULL DEFAULT 'session'
        CHECK (persistence IN ('none','session','persisted'));

UPDATE tasks
SET persistence = 'persisted'
WHERE mode = 'durable' AND persistence = 'session';
